/*--- formatted by Jindent 2.1, (www.c-lab.de/~jindent) ---*/

package rad.ijplugin.dcm;

import java.awt.*;


/**
 * Diese Klasse implementiert einen alternativen Konstruktor fuer
 * <code>GridBagConstraints</code>. Dieser ist ab Java 1.2 Bestandteil von
 * <code> java.awt</code>.<br>
 * Dieser Konstruktor wurde von JBuilder 2 immer dann verwendet, wenn ein
 * <code>GridBagConstraints</code> erzeugt werden musste.
 * @version  2000.05.04
 */
public class GridBagConstraints2 extends GridBagConstraints implements java.io.Serializable {


	/**
	 * Constructor declaration
	 *
	 *
	 * @param gridx
	 * @param gridy
	 * @param gridwidth
	 * @param gridheight
	 * @param weightx
	 * @param weighty
	 * @param anchor
	 * @param fill
	 * @param insets
	 * @param ipadx
	 * @param ipady
	 *
	 */
	public GridBagConstraints2(int gridx, int gridy, int gridwidth, int gridheight, double weightx, double weighty, int anchor, int fill, Insets insets, int ipadx, int ipady) {
		this.gridx = gridx;
		this.gridy = gridy;
		this.gridwidth = gridwidth;
		this.gridheight = gridheight;
		this.fill = fill;
		this.ipadx = ipadx;
		this.ipady = ipady;
		this.insets = insets;
		this.anchor = anchor;
		this.weightx = weightx;
		this.weighty = weighty;
	}


	/**
	 * Liefert die String-Darstellung des Objektes
	 */
	public String toString() {
		return ": " + gridx + "," + gridy + "," + gridwidth + "," + gridheight;		// NORES
	} 

}


/*--- formatting done in "My Own Convention" style on 04-30-2000 ---*/

