/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.math;

/**
 * Written By:  Michael Reese Bastian <P>
 * Last Modified:  22 October 1997 <P>
 *
 * This class allows a programmer to create a (square) identity matrix of arbitrary order. <P>
 */

public class IdentityMatrix extends Matrix
{
  /**
   * This constructor creates an identity matrix of order <CODE>n</CODE>. <P>
   */
  
  public IdentityMatrix(int n)
  {
    super(n, n);
    
    for (int i = 0; i < n; ++i)
      mem[i][i] = 1.0;
  }
  
  public static void main(String[] args)
  {
    IdentityMatrix I = new IdentityMatrix(4);
    
    Matrix A = I.mult(3);
    
    System.out.println(I);
    System.out.println(A);
  }
}
