/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.gui;
import jigl.image.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import jigl.image.utils.*;
import jigl.signal.*;
import jigl.image.levelOps.*;
import jigl.image.utils.*;
import java.util.*;
import jigl.image.warp.*;


/** CommandLine Shell is an example program to show how the JIGL can be used using command lines.
    This program simply loads up an image copies it and outputs the copy to another file.
*/
class CommandLineShell2 {

 private static String[] argv=null;
 static SequenceCanvas s=new SequenceCanvas();
 static CloseableFrame frame=new CloseableFrame("Test");


public CommandLineShell2(){

}

public static void main(String[] argv) {

   int total=10000; 
    
   
  try{
	 Clip clip=new Clip(0,255);
   GrayImage image=null;   
   ImageInputStream is = new ImageInputStream(argv[0]);   
   image = ConvertImage.toGray(is.read()); 
	 is.close(); 
		
	 CloseableFrame frame1=new CloseableFrame("Results");
	 ImageCanvas canvas1=new ImageCanvas(image);
	 frame1.add(canvas1);
	 frame1.setSize(image.X(), image.Y());
	 frame1.setVisible(true);
		
	 java.util.Random random=new java.util.Random();
	 ImageOutputStream os=null;
	 int range=50;
	 GrayImage image2=(GrayImage)image.copy();
	 int int_val=0;
	 float float_val=0;
	 float choice=0;
	 for (int z=0; z<40; z++){
	  Integer i=new Integer(z);
		image2=Noise.gaussian(image2,20);
		image2=(GrayImage)clip.apply(image2);
	  os=new ImageOutputStream(argv[1]+i.toString()+".pgm");
	  os.write(image2);
		os.close();
		
		frame1=new CloseableFrame("Results");
	  canvas1=new ImageCanvas(image2);
	  frame1.add(canvas1);
	  frame1.setSize(image.X(), image.Y());
	  frame1.setVisible(true);
		
		image2=(GrayImage)image.copy();
	  
	  System.out.println(z);
	}
	 
	
	 	 }
	 catch(Exception e){e.printStackTrace();}
  
   
 
 }

}
