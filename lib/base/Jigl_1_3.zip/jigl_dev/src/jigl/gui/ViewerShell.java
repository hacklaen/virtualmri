/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.gui;
import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import java.net.*;

import jigl.*;
import jigl.image.*;

 class ViewerShell extends Applet {

  
  Label ROILine = new Label("Second Status Line:");
  Label statusLine = new Label("Status Line:                                                                ");
  
  //Place to put all the images.
  static Panel imagePanel=new Panel();
  
  public static MenuWindow gui;
 

  public static void main(String argv[]) {
    ViewerShell viewer = new ViewerShell();
    
    gui = new MenuWindow(viewer);
  
  }  
  
}

  
class MenuWindow extends Frame implements ActionListener,
                                   ItemListener {
    boolean inAnApplet = true;
   
    PopupMenu popup;
		
    CloseableFrame frame= new CloseableFrame("Sample Shell Application");
		
    ViewerShell viewer;   

    public MenuWindow(ViewerShell viewer2) {
		    
        viewer=viewer2;
        MenuBar mb;
        Menu m1, m2, m3, m4, m5;
        MenuItem mi1_1, mi1_2, mi1_3, mi1_4, mi3_1, mi3_2, mi3_3, mi3_4, mi4_1,
                 mi4_2, mi5_1, mi5_2, mi3_5, mi2_5, mi2_6,
                 pmi1, pmi2, mi5_1_duplicate, mi2_1, mi2_2, mi2_3, mi2_4;
      
        frame.setLayout(new BorderLayout());          
        frame.setBackground(new Color(12632256));

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                if (inAnApplet) {
                    dispose();
                } else {
		  System.exit(0);
                }
            }
        });

      
        //Build the menu bar.
        mb = new MenuBar();
        frame.setMenuBar(mb);

	      frame.setBackground(Color.lightGray);
	
        //Build first menu in the menu bar.
        m1 = new Menu("Main 1", true);
        mb.add(m1);
        mi1_1 = new MenuItem("Main 1 Option 1");
        m1.add(mi1_1); 
        mi1_2 = new MenuItem("Main 1 Option 2");
      	m1.add(mi1_2);
        mi1_3 = new MenuItem("Main 1 Option 3");
	      m1.add(mi1_3);
	      m1.addSeparator();
        mi1_4 = new MenuItem("Main 1 Option 4");
	      
        m1.add(mi1_4);
        
        
        //Build second menu in the menu bar.
        m2 = new Menu("Main 2");
        mb.add(m2);
        mi2_1 = new MenuItem("Main 2 Option 1");
        m2.add(mi2_1);
        m2.addSeparator();
	      mi2_2 = new MenuItem("Main 2 Option 2");
	      m2.add(mi2_2);
	      mi2_3 = new MenuItem("Main 2 Option 3");
	      m2.add(mi2_3);
	      mi2_4 = new MenuItem("Main 2 Option 4");
	      m2.add(mi2_4);
	      m2.addSeparator();
	      mi2_5 = new MenuItem("Main 2 Option 5");
	      m2.add(mi2_5);
	      mi2_6 = new MenuItem("Main 2 Option 6");
	      m2.add(mi2_6);
       

        //Build third menu in the menu bar.
        m3 = new Menu("Main 3");
        mb.add(m3);
        mi3_1 = new MenuItem("Main 3 Option 1");
        m3.add(mi3_1);
        mi3_2 = new MenuItem("Main 3 Option 2");
        m3.add(mi3_2);
        m3.addSeparator();
        mi3_3 = new MenuItem("Main 3 Option 3");
        m3.add(mi3_3);
        mi3_4 = new MenuItem("Main 3 Option 4");
        m3.add(mi3_4);
	      mi3_5 = new MenuItem("Main 3 Option 5");
        m3.add(mi3_5);

        //Build fourth menu in the menu bar.
        m4 = new Menu("Main 4");
        mb.add(m4);
        mi4_1 = new MenuItem("Main 4 Option 1");
        m4.add(mi4_1);
        mi4_2 = new MenuItem("Main 4 Option 2");
        m4.add(mi4_2);

        //Register as an ActionListener for all menu items.
        m1.addActionListener(this);
        m2.addActionListener(this);
        m3.addActionListener(this);
        m4.addActionListener(this);
				
	      
        // status lines
        Panel statusPanel = new Panel();
        statusPanel.setLayout(new FlowLayout(FlowLayout.LEFT));				
        frame.add(statusPanel,"South");
        statusPanel.add(viewer.statusLine);
        statusPanel.add(viewer.ROILine);

        ScrollPane pane = new ScrollPane();
	                   
        //space for the images
				viewer.imagePanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        pane.add(viewer.imagePanel,"Center");
        frame.add(pane,"Center");
        
				//show the GUI
        frame.setSize(495,375);
        frame.setVisible(true);
				
				System.out.println("Done");
        
    }

    
    class PopupListener extends MouseAdapter {
        public void mousePressed(MouseEvent e) {
            maybeShowPopup(e);
        }

        public void mouseReleased(MouseEvent e) {
            maybeShowPopup(e);
        }

        private void maybeShowPopup(MouseEvent e) {
            if (e.isPopupTrigger()) {
                popup.show(e.getComponent(),
                           e.getX(), e.getY());
            }
        }
    }
		
    public void actionPerformed(ActionEvent e) {
         if (e.getActionCommand()=="Main 1 Option 1")
	         {
             viewer.statusLine.setText("Main 1 Option 1");
             //do some action
           } 
        else if (e.getActionCommand()=="Main 1 Option 2")
	         {
             viewer.statusLine.setText("Main 1 Option 2");
             //do some action
           } 
        else if (e.getActionCommand()=="Main 1 Option 3")
	         {
             viewer.statusLine.setText("Main 1 Option 3");
             //do some action
           } 
        else if (e.getActionCommand()=="Main 1 Option 4")
	         {
             viewer.statusLine.setText("Main 1 Option 4");
             //do some action
           } 
        else if (e.getActionCommand()=="Main 2 Option 1")
	         {
             viewer.statusLine.setText("Main 2 Option 1");
             //do some action
           } 
        else if (e.getActionCommand()=="Main 2 Option 2")
	         {
             viewer.statusLine.setText("Main 2 Option 2");
             //do some action
           } 
	      else if (e.getActionCommand()=="Main 2 Option 3")
	         {
             viewer.statusLine.setText("Main 2 Option 3");
             //do some action
           } 
        else if (e.getActionCommand()=="Main 2 Option 4")
	         {
             viewer.statusLine.setText("Main 2 Option 4");
             //do some action
           } 
        else if (e.getActionCommand()=="Main 2 Option 5")
	         {
             viewer.statusLine.setText("Main 2 Option 5");
             //do some action
           } 
        else if (e.getActionCommand()=="Main 2 Option 6")
	         {
             viewer.statusLine.setText("Main 2 Option 6");
             //do some action
           } 
        else if (e.getActionCommand()=="Main 3 Option 1")
	         {
             viewer.statusLine.setText("Main 3 Option 1");
             //do some action
           } 
        else if (e.getActionCommand()=="Main 3 Option 2")
	         {
             viewer.statusLine.setText("Main 3 Option 2");
             //do some action
           } 
	      else if (e.getActionCommand()=="Main 3 Option 3")
	         {
             viewer.statusLine.setText("Main 3 Option 3");
             //do some action
           } 
	      else if (e.getActionCommand()=="Main 3 Option 4")
	         {
             viewer.statusLine.setText("Main 3 Option 4");
             //do some action
           } 
        else if (e.getActionCommand()=="Main 4 Option 1")
	         {
             viewer.statusLine.setText("Main 4 Option 1");
             //do some action
           } 
				else if (e.getActionCommand()=="Main 4 Option 2")
	         {
             viewer.statusLine.setText("Main 4 Option 2");
             //do some action
           } 
    }

    public void itemStateChanged(ItemEvent e) {
       
    }

         
}










