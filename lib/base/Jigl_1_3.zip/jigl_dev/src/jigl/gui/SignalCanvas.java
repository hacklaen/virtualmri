/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

/**
   SignalFrame - provides  a way to display signals in a frame
   Currently supports:  Jigl signals, Java signals (.gif, .jpg, .jpeg),
   and PPM signals (.ppm, .pgm, .pbm).
*/

package jigl.gui;
import jigl.*;


import java.awt.*;
import java.io.*;

import java.util.*;
import java.awt.Rectangle.*;
import jigl.image.*;
import jigl.signal.*;

/** SignalCanvas is a class made to facilitate the displaying of a JIGL signal*/
public class SignalCanvas extends Canvas {
  
	/** used to wait until the signal loads before continuing*/
  MediaTracker m_tracker;
	/** Java signal */
  protected java.awt.Image image;
	/** JIGL signal */
  protected jigl.signal.Signal jsignal;

  /** Upper x corner of the selection box */
  public int mouseux=0;
	/** Lower x corner of the selection box */
  public int mouselx=0;
	/** Lower y corner of the selection box */
  public boolean mouse_clicked=false;
	/** Used as a toggle on the SignalCanvas*/
  public boolean box_draw=true;
 
  
  /** Creates an empty SignalCanvas */
  public SignalCanvas() {
    super();
  }

  /** Creates an SignalCanvas from a file
	    @param fname filename */
  public SignalCanvas(String fname) throws jigl.signal.FileExtensionNotSupportedException, BadSignalException, jigl.signal.IllegalPBMFormatException, 
	                                        SignalNotSupportedException, FileNotFoundException, IOException{
    super();
    image = getSignalFromFile(fname);
  }

  
	/** Creates an SignalCanvas from a DiscreteSignal
	    @param sig GraySignal */
  public SignalCanvas(DiscreteSignal sig) throws BadSignalException{
    super();
    image = getJavaSignal(sig);
    jsignal = sig;
  }  

 
  /** Creates an SignalCanvas from a RealSignal
	    @param sig RealGraySignal */
  public SignalCanvas(RealSignal sig) throws BadSignalException{
    super();
    image = getJavaSignal(sig);
    jsignal = sig;
  }  

  /** Creates an SignalCanvas from a ComplexSignal
	    @param sig CpmplexSignal */
  public SignalCanvas(ComplexSignal sig) throws BadSignalException{
    super();
    image = getJavaSignal(sig);
    jsignal = sig;
  }  

  /** Creates an SignalCanvas from a JIGL Signal
	    @param sig JIGL Signal */
  public SignalCanvas(jigl.signal.Signal sig) throws BadSignalException{
    super();
    image = getJavaSignal(sig);
    jsignal = sig;
  }
  
	
	/** Sets the Java signal to <i>sig</i> and jsignal to null*/
	public void setSignal(java.awt.Image sig) {
    image = sig;
    jsignal = null;
  }
  	
	/** Sets the Java signal to <i>sig</i> and jsignal to <i>sig</i>*/
	public void setSignal(jigl.signal.Signal sig) throws BadSignalException{
    image = getJavaSignal(sig);
    jsignal = sig;
  }
	
  /** Returns the JIGL signal*/
  public jigl.signal.Signal getSignal() {
    return jsignal;
  }

  /** Returns the Java signal*/
  public java.awt.Image getJavaSignal(){
    return image;
  }
  
	/** Returns an instance of Graphics that, when modified, modifies the Java signal*/ 
  public Graphics setOffScreen(){
    java.awt.Image tempSignal;
    Graphics g;

    tempSignal=image;
    image=this.createImage(image.getWidth(this), image.getHeight(this));
    g = image.getGraphics();
    g.drawImage(tempSignal,0,0,this);
 
    return g;
    

  }

  /** Returns an instance of Graphics that, when modified, modifies the Java signal
	    @param xfactor zoom of x axis
			@param yfactor zoom of y axis*/ 
  public Graphics setOffScreen(double xfactor, double yfactor){
    java.awt.Image tempSignal;
    Graphics g;

    tempSignal=image;
    image=this.createImage((int)(image.getWidth(this)*xfactor), (int)(image.getHeight(this)*yfactor));
    
    g = image.getGraphics();
    
    g.drawImage(tempSignal,0,00, 
                (int)(tempSignal.getWidth(this)*xfactor), (int)(tempSignal.getHeight(this)*yfactor),this);
    
    
    return g;
    

  }
	
  /** Overrides Component.setVisible(boolean)*/
  public void setVisible(boolean b) {
	   setSize(imWidth(),imHeight());
     super.setVisible(b);
   
  }

  /** Returns the signal width*/
  public int imWidth() {
    return image.getWidth(this);
  }
	
	public int imHeight() {
    return image.getHeight(this);
  }
  
  /** Takes a jigl signal as input, converts it to a java
      signal, and returns the java signal.
			@param sig the JIGL signal*/
  public java.awt.Image getJavaSignal(jigl.signal.Signal sig) throws BadSignalException, RuntimeException{

    int w = 0;
    int h = 0;
    java.awt.Image jsig = null;
   
    
    
		if (sig instanceof DiscreteSignal){
		
		   int max=Integer.MIN_VALUE;
       int min=Integer.MAX_VALUE;
			 
		   DiscreteSignal nsig=ConvertSignal.toDiscrete(sig);
		    for (int x=0; x<nsig.length(); x++) {
             if ((short)nsig.get(x)>max) max=(short)nsig.get(x);
             if ((short)nsig.get(x)<min)  min=(short)nsig.get(x);
							 
	      }
			 
			 short[][] new_data= new short [max][nsig.length()];
			 GrayImage gimage = new GrayImage(nsig.length(), max);
       for (int x=0; x<nsig.length(); x++) 
          for (int y=0; y<max; y++) 
	      {
             if ((max-y)<nsig.get(x)) new_data[y][x]=0;
              else new_data[y][x]=255;
						gimage.set(x,y,new_data[y][x]);
         }
       w = gimage.X();
			 h = gimage.Y();
       jsig = createImage(gimage.getJavaImage());  
			 return jsig;
			}
	 else {
		    float max=Float.MIN_VALUE;
        float min=Float.MAX_VALUE;
		    RealSignal nsig=ConvertSignal.toRealDiscrete(sig);
		    for (int x=0; x<nsig.length(); x++) {
				     if (nsig.get(x)>max) max=nsig.get(x);
             if (nsig.get(x)<min) min=nsig.get(x);
						}
				
			 float[][] new_data= new float [(int)max][nsig.length()];
			 RealGrayImage gimage = new RealGrayImage(nsig.length(), (int)max);
       for (int x=0; x<nsig.length(); x++) 
          for (int y=0; y<max; y++) 
	      {
             //try{
							if ((max-y)<nsig.get(x)) new_data[y][x]=0;
              else new_data[y][x]=255;
						  gimage.set(x,y,(int)new_data[y][x]);
						//}catch (Exception e) {System.out.println(x+" uh oh  "+y);}
					   
         }
       w = gimage.X();
			 h = gimage.Y();
       jsig = createImage(gimage.getJavaImage()); 
			 return jsig;
			 
			}		
	
  }

  /** Gets a JIGL signal from a file.
      This currently supports Java files (.gif, .jpg),
      and PPM files (.ppm, .pgm, .pbm).  The file extension must be one of the above, or it won't look at it.
			@param fname filename
  */
  public java.awt.Image getSignalFromFile(String fname) throws jigl.signal.FileExtensionNotSupportedException, BadSignalException, jigl.signal.IllegalPBMFormatException,
	                                                            SignalNotSupportedException, IOException, FileNotFoundException{
    
    java.awt.Image sig = null;
    
    //setLayout(new FlowLayout());    // NEED to specify a layout manager!!
    
    if (fname.endsWith(".gif") || fname.endsWith(".jpg") ||
        fname.endsWith(".jpeg")) {
      
      // do Java file load
      Toolkit toolkit = Toolkit.getDefaultToolkit();
      sig = toolkit.getImage(fname);
      m_tracker = new MediaTracker(this);
      m_tracker.addImage(sig,0);
      try {
        m_tracker.waitForAll();
      }
      catch (InterruptedException e) {
        System.out.println("Interrupted signal load.");
      }
      
      jsignal = null;
      return sig;
    }
    else if (fname.endsWith(".pds") || fname.endsWith(".prs")) {
      
      // do a Jigl load
     
        SignalInputStream is = new SignalInputStream(fname);
        jsignal = is.read();
				return getJavaSignal(jsignal);
     }
		else throw new jigl.signal.FileExtensionNotSupportedException();
    
             // shouldn't get here if all goes well
  }
  
	/** Repaints the SignalCanvas (including the selection box)
	    @g Graphics */
  public void update (Graphics g) {
    java.awt.Image i = image;
    g.drawImage(i, 0, 0, this);
    Graphics gr = this.getGraphics();
    
    gr.setXORMode(Color.white);
    //gr.drawLine (this.mouseux,0,this.mouselx,0); 
    //gr.drawLine (this.mouseux,1,this.mouselx,1);
    
  }
	
	public void paint (Graphics g) {
	  update(g);
	}
 
  

 
   

}
