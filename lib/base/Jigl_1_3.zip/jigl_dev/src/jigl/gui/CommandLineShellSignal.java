/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.gui;
import jigl.signal.*;
import java.io.*;
import java.awt.*;
import jigl.signal.*;
import jigl.signal.levelOps.*;
import jigl.signal.utils.*;

/** CommandLine Shell is an example program to show how the JIGL can be used using command lines.
    This program simply loads up an image copies it and outputs the copy to another file.
*/
class CommandLineShellSignal
{
private static String[] param=null;

public static void main(String[] argv) {
  
	try{
	  RealSignal signal=(RealSignal)SignalGenerator.gaussian(128,64,5);
		
		float total=0;
		for (int x=0; x<signal.length(); x++){
		  total=total+signal.get(x);
		}
		for (int x=0; x<signal.length(); x++){
		  signal.set(x, signal.get(x)/total);
		}
		
		SignalOutputStream os=new SignalOutputStream("Gaussian128n.dat");
		os.write(signal);
		os.close();
	
  
	    
  System.out.println("Done");
	}catch (Exception e) {e.printStackTrace();}
	}
}

