/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.gui;
import jigl.image.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import jigl.image.utils.*;
import jigl.signal.*;
import jigl.image.levelOps.*;
import jigl.image.utils.*;
import java.util.*;
import jigl.image.warp.*;


/** CommandLine Shell is an example program to show how the JIGL can be used using command lines.
    This program simply loads up an image copies it and outputs the copy to another file.
*/
class CommandLineShell {

 private static String[] argv=null;
 static SequenceCanvas s=new SequenceCanvas();
 static CloseableFrame frame=new CloseableFrame("Test");


public CommandLineShell(){

}

public static void main(String[] argv) {

   int total=10000; 
    
   
   try{
   GrayImage image=null;   
   ImageInputStream is = new ImageInputStream(argv[0]);   
   image = ConvertImage.toGray(is.read()); 
	is.close();  
	java.util.Random random=new java.util.Random();
	ImageOutputStream os=null;
	int range=50;
	GrayImage image2=null;
	int int_val=0;
	int x1=0;
	int y1=0;
	float float_val=0;
	float choice=0;
	for (int x=0; x<40; x++){
	 image2=(GrayImage)image.copy();
	 for (int y=0; y<total; y++){
	      choice=random.nextFloat();
		   int_val=random.nextInt();
			x1=random.nextInt();
			y1=random.nextInt();
		   int_val=int_val%range;
			x1=x1%image.X();
			y1=y1%image.Y();
			if (x1<0) x1= -x1;
			if (y1<0) y1= -y1;
			if (choice>0.5) image2.add(x1,y1,int_val);
					   else image2.subtract(x1,y1,int_val);
     }
	  Integer i=new Integer(x);
	  os=new ImageOutputStream(argv[1]+i.toString()+".pgm");
	  os.write(image2);
	  os.close();
	  System.out.println(x);
	}
	 
	
	 	 }
	 catch(Exception e){e.printStackTrace();}
  
   
 
 }

}
