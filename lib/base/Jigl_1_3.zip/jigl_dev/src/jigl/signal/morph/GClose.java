/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.signal.morph;

import jigl.signal.*;
import jigl.math.*;
import java.io.*;

public class GClose implements Morph{

SignalKernel kernel;
int center_x;


/**Initilizes Close
   ker SignalKernel
	 x center x value
	 */
public GClose(SignalKernel ker,int x){
	kernel=ker;
	center_x=x;
	
}

/** Closes this signal*/
	public Signal apply(Signal gr)throws SignalNotSupportedException{
	  if (gr instanceof DiscreteSignal) return apply((DiscreteSignal)gr);
	  else if (gr instanceof RealSignal) return apply((RealSignal)gr);
		else throw new SignalNotSupportedException();
	}
	
/** Closes a DiscreteSignal*/
 public DiscreteSignal apply(DiscreteSignal signal){
	DiscreteSignal signal2=(DiscreteSignal)signal.copy();
	GDilate d=new GDilate(kernel, center_x);
	GErode e=new GErode(kernel, center_x);
	signal2=d.apply(signal);
	signal2=e.apply(signal2);
	return signal2;
	
 }
	
 /** Closes a RealSignal*/
 public RealSignal apply(RealSignal signal){
	RealSignal signal2=(RealSignal)signal.copy();
	GDilate d=new GDilate(kernel, center_x);
	GErode e=new GErode(kernel, center_x);
	signal2=d.apply(signal);
	signal2=e.apply(signal2);
	return signal2;
	
 }
	
public static void main(String[] argv) {
  
	try{
	Signal signal=null;
	Signal signal2=null;
	Signal signal3=null;
  String inputfile = argv[0];
	String kernelfile = argv[1];
	
	SignalInputStream is = new SignalInputStream(inputfile);
	signal = is.read();
	is.close();
	
	is = new SignalInputStream(kernelfile);
	signal2 = is.read();
	is.close();
	
	Integer f_val1 = Integer.valueOf(argv[2]);
  
	int val1=f_val1.intValue();
	
	
	GClose close=new GClose((SignalKernel)signal2, val1);
	signal3=close.apply(signal);
  
	//put command line stuff here.
	
	// create a new SignalOutputStream
  SignalOutputStream os = new SignalOutputStream(argv[4]);
  os.write(signal3);
  os.close();

  } catch (Exception e) {e.printStackTrace();} 
  }
	 
}
