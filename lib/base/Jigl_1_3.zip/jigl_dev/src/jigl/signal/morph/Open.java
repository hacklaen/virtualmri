/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.signal.morph;

import jigl.signal.*;
import jigl.math.*;
import java.io.*;

public class Open implements Morph{

SignalKernel kernel;
int center_x;


/**Initilizes Open*/
public Open(SignalKernel ker,int x){
	kernel=ker;
	center_x=x;
	
}

/** Performs an Open on this signal*/
	public Signal apply(Signal gr)throws SignalNotSupportedException{
	  if (gr instanceof BinarySignal) return apply((BinarySignal)gr);
		else throw new SignalNotSupportedException();
	}
	
 /** Performs an Open on a BinarySignal*/
 public BinarySignal apply(BinarySignal signal){
	BinarySignal signal2=(BinarySignal)signal.copy();
	Dilate d=new Dilate(kernel, center_x);
	Erode e=new Erode(kernel, center_x);
	signal2=e.apply(signal);
	signal2=d.apply(signal2);
	return signal2;
	
 }
	
 
public static void main(String[] argv) {
  
	try{
	Signal signal=null;
	Signal signal2=null;
	Signal signal3=null;
  String inputfile = argv[0];
	String kernelfile = argv[1];
	
	SignalInputStream is = new SignalInputStream(inputfile);
	signal = is.read();
	is.close();
	
	is = new SignalInputStream(kernelfile);
	signal2 = is.read();
	is.close();
	
	Integer f_val1 = Integer.valueOf(argv[2]);
  
	int val1=f_val1.intValue();
	
	
	Open open=new Open((SignalKernel)signal2, val1);
	signal3=open.apply((BinarySignal)signal);
  
	//put command line stuff here.
	
	// create a new SignalOutputStream
  SignalOutputStream os = new SignalOutputStream(argv[4]);
  os.write(signal3);
  os.close();

  } catch (Exception e) {e.printStackTrace();}
  }	 
}
