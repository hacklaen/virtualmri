/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */
package jigl.signal;
import jigl.*;
import java.awt.image.*;


/** BinarySignal is a 1-d array of byte.  All the values in a BinarySignal is always eithier a one or a zero. */

public class BinarySignal implements Signal {	

  /**One dimensional integer array */
	protected byte[] data;
	
	/**Cartesian width */
	protected int length;
	
	/**Creates an empty one dimensional BinarySignal with a height and width of zero*/
	public BinarySignal() {
		length = 0;
		
		data = null;
	}
	
	/**Creates a one dimensional BinarySignal with a height and width of x and y repectively*/
	public BinarySignal(int x) {
		length = x;
		data = new byte[length];
	}
	
		
	/**Creates a one dimensional BinarySignal with a height and width of x and y repectively
	   @param x width of image
		 @param y height of image
		 @param dat one dimensional array of short.  The array is length x*y.*/
	
	
	public BinarySignal(int x, byte[] dat) {
		length = x;
		
		int count=0;
		
		data = new byte[length];
		
		  for (int b=0; b<length; b++){
			   
			   if (dat[b]>0) data[b]=1;
				 else data[b]=0;
				 }
		}
	
	
	/**Creates a one dimensional BinarySignal from a GraySignal*/
  public BinarySignal(DiscreteSignal img) {
	  length = img.length();
		data = new byte[length];
		  for (int b=0; b<length; b++)
			  if (img.get(b)>0) 
				  data[b]=1;
				  else data[b]=0;
	}
	
	/**Creates a one dimensional BinarySignal from a RealGraySignal*/
  public BinarySignal(RealSignal img) {
	  length = img.length();
		
		data = new byte[length];
		
		  for (int b=0; b<length; b++)
			  if (img.get(b)>0) set(b,1);
				else set(b,0);
	}
	
	/**Creates a one dimensional BinarySignal (shallow copy) from BinarySignal img*/	
	public BinarySignal(BinarySignal img) {
		length = img.length();
		data = img.data;
	}

  	
	/**Makes a deep copy of this Signal
	  @param none
		@return a deep copy of BinarySignal
	*/
	public Signal copy() {
		BinarySignal g = new BinarySignal(length);
			for(int x = 0; x < length; x++) {
				g.data[x] = data[x];
		}
		return g;
	}

		
	
	/**Returns the width (maximum length value)
	  @param none */
	public final int length() {
		return length;
	}

  

	/**Returns the pixel value at the given x value
     @param x  the length coordinant 
     @param y  the Y coordinant */
	public final byte get(int x) {
		return (byte)data[x];
	}
		
  /**Sets the pixel value at x to a given value
     @param x the length coordinant 
     @param y the Y coordinant 
     @param value the value to set the pixel to */
	public final void set(int x, int value) {
		if (value>0) data[x] = 1;
		else data[x]=0;
	}
	
 /** Finds the union between this image and another BinarySignal
	   @return this*/
 public final BinarySignal union(BinarySignal image){
   		for (int x = 0; x < length; x++) 
			  if (image.get(x)!=data[x]) data[x]=1;
 	  return this;
	}

/** Finds the intersection between this image and another BinarySignal
    @return this*/
 public final BinarySignal intersection(BinarySignal image){
  		for (int x = 0; x < length; x++) 
			  if (image.get(x)!=data[x]) data[x]=0;
				
		return this;
 }
	
/** Returns the complement of this image*/	
 public final BinarySignal compliment(BinarySignal image){
	 		for (int x = 0; x < length; x++) 
			  if (data[x]==0) data[x]=1;
				else data[x]=0;
				
		return this;
 }
/** Counts the number of "on" pixels*/
 public final int count(){
	
	 int count=0;
	 
			for (int x = 0; x < length; x++) 
			  if (data[x]!=0) count++;
				
		return count;
 }

/** Returns the difference of this image and a BinarySignal
    @return this*/
public final BinarySignal difference(BinarySignal image){
	
	 
			for (int x = 0; x < length; x++) 
			  if ((data[x]==1) && (image.get(x)==0)) data[x]=1;
				else if ((data[x]==1) && (image.get(x)==0)) data[x]=1;
				else data[x]=0;
				
		return this;
 }
 
/** Performs a shift on this image
    @param horizonal for right shift horizonal is positive for left it is negative
		@param vertical for down shift vertical is positive for up it is negative
    @return this*/
public final BinarySignal shift(int horizonal, int vertical){

 BinarySignal image2=(BinarySignal)this.copy();
 byte set1=0;
 
			for (int x = 0; x < length; x++) {
			  if (x-horizonal<0 || x-horizonal>=length) set1=0;
				else set1=image2.get(x-horizonal);
			  data[x]=set1;
			}
 return this;			
 }

}

