/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

/**
	A discrete signal is a 1-d of shorts
	
	DiscreteSignal implements Signal
 */

package jigl.signal;
import java.*;



public class DiscreteSignal implements Signal {	

  /**One dimensional integer array */
	protected short[] data;
	
	/**Length of the Signal*/
	protected int length;

  /**Creates an empty one dimensional DiscreteSignal with a height and width of zero*/
	public DiscreteSignal() {
		length = 0;
		data = null;
	}

  /**Creates an empty one dimensional of length x*/
	public DiscreteSignal(int x) {
		length = x;
		data = new short[length];
	}
	
	/**Creates a one dimensional DiscreteSignal (shallow copy) for a DiscreteSignal*/
	public DiscreteSignal(DiscreteSignal s) {
		length = s.length();
		data = s.data();
	}

	/**Makes a deep copy of this signal
	  @param none
		@return a deep copy of DiscreteSignal
	*/
	public Signal copy() {
		DiscreteSignal s = new DiscreteSignal(length);
		s.length = length;
		for(int x = 0; x < length; x++) {
			s.data[x] = data[x];
	}
		return s;
	}

  /**Returns the length of this signal*/
	public final int length() {
		return length;
	}

	 /** Makes a shallow copy of a JIGL signal's sample buffer
      @param none
			@return a pointer to DiscreteSignal*/
	public final short[] data() {
		return data;
	}


	/**Returns the sample value at the given x, y value
     @param x  the X coordinant  */
	public final int get(int x) {
		return (int)data[x];
	}
	
	/**Sets the sample value at x, y to a given value
     @param x the X coordinant 
     @param value the value to set the sample to */
	public final void set(int x, int value) {
		data[x] = (short)value;
	}
		
	
	/**Clears the signal to zero
     @param none 
	*/
	public final DiscreteSignal clear() {
		clear(0);
		return this;
	}
	
	/** 
		Clears to constant value
		@param val the value to "clear" the signal to 
	*/
	public final DiscreteSignal clear(int val) {
		for (int x = 0; x < length; x++) {
			data[x] = (short)val;
		}
		return this;
	}
	
	
	/**Adds a value to a single sample
     @param x X-coordinant 
     @param value the value to add to the sample */
	public final void add(int x, int value) {
		data[x] += (short)value;
	}
	
	/**Subtracts a value from a single sample
     @param x X-coordinant 
     @param value the value to subtract from the sample*/
	public final void subtract(int x, int value) {
		data[x] -= (short)value;
	}
	
	/**Mutiplies a single sample by a value
     @param x X-coordinant 
     @param value - the value to mutiply to the sample */
	public final void multiply(int x, int value) {
		data[x] *= (short)value;
	}
	
	/**Divides a single sample by a value
     @param x X-coordinant 
     @param value - the value to mutiply to the sample */
	public final void divide(int x, int value) {
		data[x] /= (short)value;
	}
	

	/**Finds the minimum value of this signal
     @param none
     @return an integer containing the minimum value 
     */
	public final int min() {
		short p;
		short min = Short.MAX_VALUE;
		for (int x = 0; x < length; x++) {
			p = data[x];
			if (p < min)
			min = p;
		}
		return (int)min;
	}
	
	/**Finds the maximum value of this signal
     @param none
     @return an integer containing the maximum value 
     */
	public final int max() {
		short p;
		short max = Short.MIN_VALUE;
		for (int x = 0; x < length; x++) {
			p = data[x];
			if (p > max)
			max = p;
		}
		return (int)max;
	}

	/**Adds a value to all the samples in this signal
     @param v value to be added to the samples 
     @return this
     */
	public final DiscreteSignal add(int v) {
		short sv = (short)v;
		for (int x = 0; x < length; x++) {
			data[x] += sv;
		}
		return this;
	}

  /**Subtracts a value from all the samples in this signal
     @param v value to be added to the samples 
     @return this
     */
	public final DiscreteSignal subtract(int v) {
		short sv = (short)v;
		for (int x = 0; x < length; x++) {
			data[x] -= sv;
		}
		return this;
	}
	
	/**Multiplies all the samples in this signal by a value
     @param v value to be added to the samples 
     @return this
     */
	public final DiscreteSignal multiply(int v) {
		short sv = (short)v;
		for (int x = 0; x < length; x++) {
			data[x] *= sv;
		}
		return this;
	}
	
	/**Divides all the samples in this signal by a value
     @param v value to be added to the samples 
     @return this
     */
	public final DiscreteSignal divide(int v)	{
		short sv = (short)v;
		for (int x = 0; x < length; x++) {
			data[x] /= sv;
		}
		return this;
	}
	
	/**Adds another DiscreteSignal to this signal
     @param im the DiscreteSignal to add 
     @return this
     */
	public final DiscreteSignal add(DiscreteSignal s)	{
		for (int x = 0; x < length; x++) {
			data[x] += s.get(x);
		}
		return this;
	}
	
	 /**Makes a copy of this image with a buffer so the resulting image has a width x and height y
	  @param none
		@return a deep copy of GrayImage
	*/
	public DiscreteSignal addbuffer(int w, int color) {
		int Y=length;
		DiscreteSignal g = new DiscreteSignal(w);
		for(int y = 0; y < Y; y++) {
				if ((y<Y)) g.data[y] = data[y];
				else g.data[y]=(short)color;
			}
			return g;
	}		
	
	/**Subtracts a DiscreteSignal from this signal
     @param im the DiscreteSignal to subtract
     @return this
     */
	public final DiscreteSignal subtract(DiscreteSignal s) {
		for (int x = 0; x < length; x++) {
			data[x] -= s.get(x);
		}
		return this;
	}
	
	/** Subtracts the second signal from the first and returns the absolute value*/
	public final DiscreteSignal diff(DiscreteSignal s) {
		for (int x = 0; x < length; x++) {
				data[x] -= s.get(x);
				if (data[x]<0) data[x]= (short)-data[x];
			}
		return this;
	}
	
	/**Multiplies a DiscreteSignal by this signal
     @param im the DiscreteSignal to multiply
     @return this
     */
	public final DiscreteSignal multiply(DiscreteSignal s) {
		for (int x = 0; x < length; x++) {
			data[x] *= s.get(x);
		}
		return this;
	}
	
	/**Divides this signal by a DiscreteSignal
     @param im the DiscreteSignal to divide
     @return this
     */
	public final DiscreteSignal divide(DiscreteSignal s) {
		for (int x = 0; x < length; x++) {
			data[x] /= s.get(x);
		}
		return this;
	}
	
	/**Prints the string in integer format. 
   <DT><DL><DL>-Example of output on an signal with width 100 and height 120:</DT>
   <DL>       <DT>100 : 120</DT>
              <DT>10 20 32 12 32 56 40 59 42 39 43 ...</DT></DL></DL></DL>*/
	public String toString() {
		String str = length + "\n";
		for (int x = 0; x < length; x++) {
			str += data[x] + " ";
		}
		str += "\n";
		return str;
	}
	

  /** Scales the range of this signal to byte (0..255)
       @param none*/
	public void byteSize() {

		// get range of this signal
		double min = min();
		double max = max();

		// keep byte signals in original range
		
		double range = max - min;

		// convert to byte depth
		int value = 0;
		for (int x = 0; x < length; x++) {
			value = (int)((255.0/range) * ((double)data[x] - min));
			value = 0x00FF & value;
			data[x] = (short)value;
		}

	}

  /** Clips the range of this signal to an arbitrary min/max
      @param min minimum value
			@param max maximum value*/
	public final void clip(int min, int max) {
		// clip
		int value = 0;
		for (int x = 0; x < length; x++) {
			value = data[x];
			value = (value > max) ? max : value;
			value = (value < min) ? min : value;
			data[x] = (short)value;
		}
	}


	/**Performs convolution in place with a kernel signal on this signal.
	   @param kernel kernel to perform the convolution with */
	public void convolve(DiscreteSignal kernel) {

		int Num = kernel.length();
		int mid = Num/2;
		double sum = 0;
		short[] value = new short[length];
		float[] kern = ConvertSignal.toRealDiscrete(kernel).data; 

		// find the sum of all values in the kernel
		for (int x = 0; x < Num; x++) {
			sum += kern[x];
		}
		
		// if the sum is not zero then normalize by the sum
		if (sum != 0){
			for (int x = 0; x < Num; x++) {
				kern[x] /=sum;
			}
		}
		
		// for every sample in the original signal
		for (int x = 0; x < length; x++) {

			//Convolve with the kernel
			sum = 0;
			for (int i = -mid; i <= mid; i++){
				try {
					sum += data[x+i] * kern[mid+i];
				}
				catch (Exception e){
					//ignore out of bounds samples
				}
			}
			value[x] = (short)sum;
		}
				
		this.data = value;
	}

	private double[] sort(double vals[], int size){
		int i,j;
		double temp;

		for (i=0;i<size;i++) {
			for (j=0;j<size-1;j++){
				try {
					if (vals[j] > vals[j+1]){
						temp = vals[j];
						vals[j] = vals[j+1];
						vals[j+1] = temp;
					}		
				}
				catch(Exception e){
				}
			}
		}
		return vals;
	}

	/**
		 Performs median filter on this signal
		 @param size the size of the median filter
	*/
	public void median(int size) {

		int Num = (size > length) ? length : size;
		int mid = Num/2;
		double value[] = new double[Num * Num];
		int count;
		
		//for every sample in the original signal
		for (int x = 0; x < length; x++) {
	
			//find median value
			count = 0;
			for (int i = -mid; i <= mid; i++){
				try {
					value[count++] = data[x+i];
				}
				catch (Exception e){
					//ignore out of bounds samples
				}
			}
			value = sort(value, count);
			data[x] = (short)value[count/2];
		}

	}
	
/***********************************************************************************
/**************************    ROI Stuff   *****************************************
/***********************************************************************************/

	/**Makes a deep copy in a Region of Interest
	  @param r Region of Interest
		@return a deep copy of a Region of Interest
	*/
	public Signal copy(ROI r) {
		DiscreteSignal s = new DiscreteSignal((r.lx()-r.ux()));
		s.length = length;
		for(int x = r.ux(); x < r.lx(); x++) {
			s.data[x] = data[x];
	}
		return s;
	}

 	/**Returns the sample value at the given x, y value
     @param x  the X coordinant  */
	public final int get(int x, ROI r) {
		return (int)data[(x+r.ux())];
	}
	
	/**Sets the sample value at x, y to a given value
     @param x the X coordinant 
     @param value the value to set the sample to */
	public final void set(int x, int value, ROI r) {
		data[(x+r.ux())] = (short)value;
	}
		
	
	/**Clears the signal to zero
     @param r Region of Interest 
	*/
	
	public final DiscreteSignal clear(ROI r) {
		clear(0);
		return this;
	}
	
	
		/** 
		Clears to constant value
		@param val the value to "clear" the signal to 
		@param r Region of Interest
	*/
	public final DiscreteSignal clear(int val, ROI r) {
		for (int x = r.ux(); x < r.lx(); x++) {
			data[x] = (short)val;
		}
		return this;
	}
	
	
	/**Adds a value to a single sample
     @param x X-coordinant 
		 @param value the value to add to the sample
     @param r Region of Interest 
      */
	public final void add(int x, int value, ROI r) {
		data[(x+r.ux())] += (short)value;
	}
	
	/**Subtracts a value from a single sample
     @param x X-coordinant 
    
     @param value the value to subtract from the sample
		 @param r Region of Interest */
			
	public final void subtract(int x, int value, ROI r) {
		data[(x+r.ux())] -= (short)value;
	}
	
	/**Mutiplies a single sample by a value
     @param x X-coordinant 
    
     @param value - the value to mutiply to the sample
		 @param r Region of Interest */
	public final void multiply(int x, int value, ROI r) {
		data[(x+r.ux())] *= (short)value;
	}
	
	/**Divides a single sample by a value
     @param x X-coordinant 
    
     @param value - the value to mutiply to the sample
		 @param r Region of Interest */
	public final void divide(int x, int value, ROI r) {
		data[(x+r.ux())] /= (short)value;
	}
	

	/**Finds the minimum value of in a Region of Interest
     @param r Region of Interest
     @return an integer containing the minimum value 
     */
	public final int min(ROI r) {
		short p;
		short min = Short.MAX_VALUE;
		for (int x = r.ux(); x < r.lx(); x++) {
			p = data[x];
			if (p < min)
			min = p;
		}
		return (int)min;
	}
	
	/**Finds the maximum value of in a Region of Interest
     @param r Region of Interest
     @return an integer containing the maximum value 
     */
	public final int max(ROI r) {
		short p;
		short max = Short.MIN_VALUE;
		for (int x = r.ux(); x < r.lx(); x++) {
			p = data[x];
			if (p > max)
			max = p;
		}
		return (int)max;
	}

	/**Adds a value to all the samples in in a Region of Interest
     @param v value to be added to the samples 
		 @param r Region of Interest 
     @return this
     */
	public final DiscreteSignal add(int v, ROI r) {
		short sv = (short)v;
		for (int x = r.ux(); x < r.lx(); x++) {
			data[x] += sv;
		}
		return this;
	}

  /**Subtracts a value from all the samples in in a Region of Interest
     @param v value to be added to the samples 
		 @param r Region of Interest 
     @return this
     */
	public final DiscreteSignal subtract(int v, ROI r) {
		short sv = (short)v;
		for (int x = r.ux(); x < r.lx(); x++) {
			data[x] -= sv;
		}
		return this;
	}
	
	/**Multiplies all the samples in in a Region of Interest by a value
     @param v value to be added to the samples
			@param r Region of Interest 
     @return this
     */
	public final DiscreteSignal multiply(int v, ROI r) {
		short sv = (short)v;
		for (int x = r.ux(); x < r.lx(); x++) {
			data[x] *= sv;
		}
		return this;
	}
	
	/**Divides all the samples in in a Region of Interest by a value
     @param v value to be added to the samples 
			@param r Region of Interest 
     @return this
     */
	public final DiscreteSignal divide(int v, ROI r)	{
		short sv = (short)v;
		for (int x = r.ux(); x < r.lx(); x++) {
			data[x] /= sv;
		}
		return this;
	}
	
	/**Adds a Region of Interest of another DiscreteSignal to a Region of Interest of this signal
     @param s the DiscreteSignal to add 
		 @param sourceSignal Region of Interest for Source Signal
		 @param destSignal Region of Interest for Destination Signal 
     @return this
     */
	public final DiscreteSignal subtract(DiscreteSignal s, ROI sourceSignal, ROI destSignal)	{
		for (int x = sourceSignal.ux(); x < sourceSignal.lx(); x++) {
				data[x] +=s.get((x-sourceSignal.ux()+destSignal.ux()));
			}
			return this;
	}
	
	/**Subtracts a Region of Interest from another DiscreteSignal from a Region of Interest of this signal
    @param s the DiscreteSignal to subtract
		 @param sourceSignal Region of Interest for Source Signal
		 @param destSignal Region of Interest for Destination Signal 
     @return this
     */
	public final DiscreteSignal multiply(DiscreteSignal s, ROI sourceSignal, ROI destSignal)	{
		for (int x = sourceSignal.ux(); x < sourceSignal.lx(); x++) {
				data[x] +=s.get((x-sourceSignal.ux()+destSignal.ux()));
			}
			return this;
	}
	
	/**Multiplies a Region of Interest of another DiscreteSignal to a Region of Interest of this signal
     @param s the DiscreteSignal to multiply
		 @param sourceSignal Region of Interest for Source Signal
		 @param destSignal Region of Interest for Destination Signal 
     @return this
     */
	public final DiscreteSignal divide(DiscreteSignal s, ROI sourceSignal, ROI destSignal)	{
		for (int x = sourceSignal.ux(); x < sourceSignal.lx(); x++) {
				data[x] +=s.get((x-sourceSignal.ux()+destSignal.ux()));
			}
			return this;
	}
	
	/**Divides this signal's Region of Interest by a Region of Interest of another DiscreteSignal
		 @param s the DiscreteSignal to divide
		 @param sourceSignal Region of Interest for Source Signal
		 @param destSignal Region of Interest for Destination Signal 
     @return this
     */
	public final DiscreteSignal add(DiscreteSignal s, ROI sourceSignal, ROI destSignal)	{
		for (int x = sourceSignal.ux(); x < sourceSignal.lx(); x++) {
				data[x] +=s.get((x-sourceSignal.ux()+destSignal.ux()));
			}
			return this;
	}
	
	/**Prints the string in integer format. 
   <DT><DL><DL>-Example of output on an signal with length 100:</DT>
   <DL>       <DT>100</DT>
              <DT>10 20 32 12 32 56 40 59 42 39 43 ...</DT></DL></DL></DL>*/
	public String toString(ROI r) {
		String str = length + "\n";
		for (int x = r.ux(); x < r.lx(); x++) {
			str += data[x] + " ";
		}
		str += "\n";
		return str;
	}
	

  /** Scales the range of a Region of Interest to byte (0..255)
       @param r Region of Interest*/
	public void byteSize(ROI r) {

		// get range of this signal
		double min = min();
		double max = max();

		
		double range = max - min;

		// convert to byte depth
		int value = 0;
		for (int x = r.ux(); x < r.lx(); x++) {
			value = (int)((255.0/range) * ((double)data[x] - min));
			value = 0x00FF & value;
			data[x] = (short)value;
		}

	}

  /** Clips the range of in a Region of Interest to an arbitrary min/max
      @param min minimum value
			@param max maximum value
			@param r Region of Interest */
	public final void clip(int min, int max, ROI r) {
		// clip
		int value = 0;
		for (int x = r.ux(); x < r.lx(); x++) {
			value = data[x];
			value = (value > max) ? max : value;
			value = (value < min) ? min : value;
			data[x] = (short)value;
		}
	}


	/**Performs convolution in place with a kernel signal on a Region of Interest.
	   @param kernel kernel to perform the convolution with 
			@param r Region of Interest */
	public void convolve(DiscreteSignal kernel, ROI r) {

		int Num = kernel.length();
		int mid = Num/2;
		double sum = 0;
		short[] value = new short[length];
		float[] kern = ConvertSignal.toRealDiscrete(kernel).data; 

		// find the sum of all values in the kernel
		for (int x = r.ux(); x < Num; x++) {
			sum += kern[x];
		}
		
		// if the sum is not zero then normalize by the sum
		if (sum != 0){
			for (int x = r.ux(); x < Num; x++) {
				kern[x] /=sum;
			}
		}
		
		// for every sample in the original signal
		for (int x = r.ux(); x < r.lx(); x++) {

			//Convolve with the kernel
			sum = 0;
			for (int i = -mid; i <= mid; i++){
				try {
					sum += data[x+i] * kern[mid+i];
				}
				catch (Exception e){
					//ignore out of bounds samples
				}
			}
			value[x] = (short)sum;
		}
				
		this.data = value;
	}

	private double[] sort(double vals[], int size, ROI r){
		int i,j;
		double temp;

		for (i=0;i<size;i++) {
			for (j=0;j<size-1;j++){
				try {
					if (vals[j] > vals[j+1]){
						temp = vals[j];
						vals[j] = vals[j+1];
						vals[j+1] = temp;
					}		
				}
				catch(Exception e){
				}
			}
		}
		return vals;
	}

	/**
		 Performs median filter on a Region of Interest
		 @param size the size of the median filter
			@param r Region of Interest 
	*/
	public void median(int size, ROI r) {

		int Num = (size > length) ? length : size;
		int mid = Num/2;
		double value[] = new double[Num * Num];
		int count;
		
		//for every sample in the original signal
		for (int x = r.ux(); x < r.lx(); x++) {
	
			//find median value
			count = 0;
			for (int i = -mid; i <= mid; i++){
				try {
					value[count++] = data[x+i];
				}
				catch (Exception e){
					//ignore out of bounds samples
				}
			}
			value = sort(value, count);
			data[x] = (short)value[count/2];
		}

	}


}
