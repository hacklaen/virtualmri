/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.signal;
import jigl.*;

/** SignalKernel is an extension of DiscreteSignal with some pre-defined kernals.*/

public class SignalKernel extends RealSignal
{
 /**
 Uniform Kernal.
 <TABLE BORDER CELLPADDING=5 COLS=1 WIDTH="13" >
 <TR><TD>1</TD><TD>1</TD></TR>
 </TABLE>
 */
 public final int UNIFORM=0;
 /**
 Difference Kernel
 <TABLE BORDER CELLPADDING=5 COLS=3 WIDTH="13" >
 <TR><TD>1</TD><TD>-1</TD></TR>
 </TABLE>
 */
 public final int DIFFERENCE=1;
 
  /**Creates a kenel of one of the predefined types
	  @param val kernel type
		@see jigl.signal.SignalKernel#UNIFORM
		@see jigl.signal.SignalKernel#DIFERENCE
		
	*/	
 public SignalKernel(int val) throws InvalidKernelException{
	
	super(2);
	
	float[] data2=null;
	
	switch (val){
	   
		case 0: {float[] data1={1,1};
		         data2=data1;
						 break;}
		
		case 1: {float[] data1={1,1};
		         data2=data1;
						 break;}
						
		
							
		default: throw new InvalidKernelException();
	}
	  data=data2;
 }
	
 /**Creates a uniform kernel of specified length
	  @param val uniform value for the kernel
		@param dimension size of kernel (dimension X dimension)
	*/
 public SignalKernel(float val, int dimension){
   super(dimension);
	 for (int x=0; x<dimension; x++)
		 	  data[x]=val;
		
}
/**Creates a kernel out of the given data.
   Note: The kernel created will have dimensions equal to the number of elements in the first row.
	 @param dat two-dimensional data array*/

public SignalKernel(float[] dat){
   super(dat.length);
	 data=dat;
}

public SignalKernel(RealSignal signal){
   super(signal);
	 data=signal.data;
}

}

