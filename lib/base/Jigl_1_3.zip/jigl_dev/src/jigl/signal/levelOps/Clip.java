/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.signal.levelOps;
import jigl.signal.*;
import java.io.*;

/** Performs a clip operation on a signal to an arbitrary min/max
*/
public class Clip implements LevelOp{

   int int_min;
	 int int_max;
	 float float_min;
	 float float_max;
   
	 /**Initilizes Clip for use with integers*/
	 public Clip(int min, int max){
		int_min=min;
		int_max=max;
	 }
  
	 /**Initilizes Clip for use with floats*/
	 public Clip(float min, float max){
		float_min=min;
		float_max=max;
	 }
		
	/** Clips the range of this signal to an arbitrary min/max*/
	public Signal apply(Signal gr)throws SignalNotSupportedException{
	  if (gr instanceof DiscreteSignal) return apply((DiscreteSignal)gr);
	  else if (gr instanceof RealSignal) return apply((RealSignal)gr);
		else throw new SignalNotSupportedException();
	}
			
	/** Clips the range of this signal to an arbitrary min/max
      @gr RealGraySignal*/
	private DiscreteSignal apply(DiscreteSignal gr){
	  if (int_min==0){
		    int_min=(int)float_min;
			  int_max=(int)float_max;
		}
		int value = 0;
		
			for (int x = 0; x < gr.length(); x++) {
				value = gr.get(x);
				value = (value > int_max) ? int_max : value;
				value = (value < int_min) ? int_min : value;
				gr.set(x,(short)value);
			}
		
    return gr;
	}
	
	/** Clips the range of this signal to an arbitrary min/max
      @gr RealGraySignal*/
	private RealSignal apply(RealSignal gr){
	  if (float_min==0 && float_max==0){
		   float_min=(float)int_min;
			 float_max=(float)int_max;
		}
		float value = 0;
		
			for (int x = 0; x < gr.length(); x++) {
				value = gr.get(x);
				value = (value > float_max) ? float_max : value;
				value = (value < float_min) ? float_min : value;
				gr.set(x,value);
			}
	
    return gr;
	}
public static void main(String[] argv) {
  
	try{
	Signal image=null;
  String inputfile = argv[2];
	Signal image2=null;
	
	
	SignalInputStream is = new SignalInputStream(inputfile);
	image = is.read();
	is.close();
	
	Float f_val1 = Float.valueOf(argv[0]);
  Float f_val2 = Float.valueOf(argv[1]);
	float val1=f_val1.floatValue();
	float val2=f_val2.floatValue();
	
	Clip clip=new Clip(val1, val2);
	
	image2=clip.apply(image);
  
	//put command line stuff here.
	
	// create a new SignalOutputStream
  SignalOutputStream os = new SignalOutputStream(argv[3]);
  os.write(image2);
  os.close();
  
	} catch (Exception e) {e.printStackTrace();}
   
  }	
}

