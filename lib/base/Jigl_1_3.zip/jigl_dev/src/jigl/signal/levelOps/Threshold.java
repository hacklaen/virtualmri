/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.signal.levelOps;
import jigl.signal.*;
import java.io.*;

/** Performs a Threshold operation on an signal
*/
public class Threshold implements LevelOp{

   int int_max;
	 float float_max;
   
	 /**Initilizes Threshold for use with integers*/
	 public Threshold(int max){
		int_max=max;
	 }
  
	 /**Initilizes Threshold for use with floats*/
	 public Threshold(float max){
		float_max=max;
	 }
		
	/** Thresholds the range of this signal to an arbitrary min/max*/
	public Signal apply(Signal gr)throws SignalNotSupportedException{
	  if (gr instanceof DiscreteSignal) return apply((DiscreteSignal)gr);
	  else if (gr instanceof RealSignal) return apply((RealSignal)gr);
		else throw new SignalNotSupportedException();
	}
		
	/** Thresholds the range of this signal to an arbitrary min/max
      @gr DiscreteSignal*/
	private DiscreteSignal apply(DiscreteSignal gr){
	  if (int_max==0){
		    int_max=(int)int_max;
		}
		int value = 0;
		
			for (int x = 0; x < gr.length(); x++) {
				value = gr.get(x);
				if (value >= int_max) value=255;
				else value = 0;
				gr.set(x,(short)value);
			}
		
    return gr;
	}
	
	/** Thresholds the range of this signal to an arbitrary min/max
      @gr RealSignal*/
	private RealSignal apply(RealSignal gr){
	  if (float_max==0){
		    float_max=(float)int_max;
		}
		float value = 0;
		
			for (int x = 0; x < gr.length(); x++) {
				value = gr.get(x);
				if (value >= float_max) value=255;
				else value = 0;
				gr.set(x,value);
			}
		
    return gr;
	}
public static void main(String[] argv) {
  
	try{
	Signal image=null;
  String inputfile = argv[1];
	Signal image2=null;
	
	
	SignalInputStream is = new SignalInputStream(inputfile);
	image = is.read();
	is.close();
	
	Float f_val1 = Float.valueOf(argv[0]);
  float val1=f_val1.floatValue();
		
	Threshold threshold=new Threshold(val1);
	
	image2=threshold.apply(image);
  
	//put command line stuff here.
	
	// create a new SignalOutputStream
  SignalOutputStream os = new SignalOutputStream(argv[2]);
  os.write(image2);
  os.close();

  } catch (Exception e) {e.printStackTrace();}
  }		
}

