/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.signal.levelOps;
import jigl.signal.*;
import java.io.*;

/** Performs a Clip operation on an signal
*/
public class ClipNeg implements LevelOp{

   /** Dummy Constructor*/
	 public ClipNeg(){
	 }
  
	/** Clips the range of this signal to zero*/
	public Signal apply(Signal gr)throws SignalNotSupportedException{
	  if (gr instanceof DiscreteSignal) return apply((DiscreteSignal)gr);
	  else if (gr instanceof RealSignal) return apply((RealSignal)gr);
		else throw new SignalNotSupportedException();
	}
 
	/** Clips the range of this signal to zero
      @gr RealSignal*/
	private DiscreteSignal apply(DiscreteSignal gr){
	  int value = 0;
		
			for (int x = 0; x < gr.length(); x++) {
				value = gr.get(x);
				if (value<0) value=0;
				gr.set(x,(short)value);
			}
		
    return gr;
	}
	
	/** Clips the range of this signal to zero
      @gr RealSignal*/
	private RealSignal apply(RealSignal gr){
		float value = 0;
		
			for (int x = 0; x < gr.length(); x++) {
				value = gr.get(x);
				if (value<0) value=0;
				gr.set(x,value);
			}
		
    return gr;
	}
public static void main(String[] argv) {
  
	try{
	Signal image=null;
  String inputfile = argv[0];
	Signal image2=null;
	
	
	SignalInputStream is = new SignalInputStream(inputfile);
	image = is.read();
	is.close();
  
	ClipNeg clipNeg=new ClipNeg();
	
	image2=clipNeg.apply(image);
  
	//put command line stuff here.
	
	// create a new SignalOutputStream
  SignalOutputStream os = new SignalOutputStream(argv[1]);
  os.write(image2);
  os.close();

  } catch (Exception e) {e.printStackTrace();} 
  }	
}

