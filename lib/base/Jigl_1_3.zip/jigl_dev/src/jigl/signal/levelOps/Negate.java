/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.signal.levelOps;
import jigl.signal.*;
import java.io.*;

/** Performs a Negate operation on an signal
*/
public class Negate implements LevelOp{

      
	 /**Dummy Constructor*/
	 public Negate(){
	 }
  
	/** Negates the values of this signal*/
	public Signal apply(Signal gr)throws SignalNotSupportedException{
	  if (gr instanceof DiscreteSignal) return apply((DiscreteSignal)gr);
	  else if (gr instanceof RealSignal) return apply((RealSignal)gr);
		else throw new SignalNotSupportedException();
	}
	
	/** Negates the values of this signal
      @gr RealSignal*/
	private DiscreteSignal apply(DiscreteSignal gr){
		int value = 0;
		
			for (int x = 0; x < gr.length(); x++) {
				value = gr.get(x);
				value = -value;
				gr.set(x,(short)value);
			}
		
    return gr;
	}
	
	/** Negates the range of this signal to an arbitrary min/max
      @gr RealSignal*/
	private RealSignal apply(RealSignal gr){
		float value = 0;
		
			for (int x = 0; x < gr.length(); x++) {
				value = gr.get(x);
				value = -value;
				gr.set(x,value);
			}
		
    return gr;
	}
	
}

