/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.signal.utils;
import java.util.*;
import jigl.*;
import jigl.signal.*;
import java.lang.*;
import java.io.*;

/**Noise adds various noise distributions to all the supported JIGL signal classes <I><U>except</U></I> ComplexSignal.
<BR>&nbsp;
<BR>&nbsp;
<TABLE BORDER WIDTH="100%" BGCOLOR="#CCCCCC" >
<TR>
<TD COLSPAN="3" BGCOLOR="#FFFF00">
<CENTER><FONT SIZE=+1>Noise Command Lines</FONT></CENTER>
</TD>
</TR>

<TR>
<TD BGCOLOR="#00B6F2">
<CENTER>&nbsp;<B>Noise Distribution</B></CENTER>
</TD>

<TD BGCOLOR="#00B6F2">
<CENTER><B>Command Line</B></CENTER>
</TD>

<TD BGCOLOR="#00B6F2">
<CENTER><B>Notes</B></CENTER>
</TD>
</TR>

<TR>
<TD WIDTH="30" BGCOLOR="#CCCCCC">&nbsp; Uniform</TD>

<TD WIDTH="90">-uniform &lt;input file> &lt;range> &lt;output file></TD>

<TD ROWSPAN="3" WIDTH="200">&nbsp; *&lt;range> is an integer value for
a DiscreteSignal, float otherwise.&nbsp;

<P>&nbsp; *&lt;standard deviation> is always a float value.&nbsp;

<P>&nbsp; *filenames need the full extension.&nbsp;
<BR>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -ex. D:\pictures\mine\test1.pgm</TD>
</TR>

<TR>
<TD WIDTH="60">&nbsp; Gaussian</TD>

<TD WIDTH="90">-gaussian &lt;input file> &lt;standard deviation> &lt;output
file></TD>
</TR>

<TR>
<TD WIDTH="60">&nbsp; Poisson</TD>

<TD WIDTH="190">-poisson &lt;input file> &lt;output file></TD>
</TR>
</TABLE>
&nbsp;
<BR>Example Command Lines:

<P>&nbsp;&nbsp;&nbsp; <FONT FACE="Courier New,Courier"><FONT SIZE=-1>-uniform
D:\pictures\test1.pgm 35 D:\pictures\output\test_out.pds</FONT></FONT>

<P><FONT FACE="Courier New,Courier"><FONT SIZE=-1>&nbsp; -gaussian D:\pictures\test1.pgm
92.1 D:\pictures\output\test_out.pds</FONT></FONT>

<P><FONT FACE="Courier New,Courier"><FONT SIZE=-1>&nbsp; -poisson D:\pictures\test1.pgm
D:\pictures\output\test_out.pds</FONT></FONT>
*/
public class Noise
{
private static String[] param=null;

public static void main(String[] argv) {
  
	try{
	int last=0;
  param=argv;
  
	String op=argv[0];
	jigl.signal.Signal signal2=null;
	int outfile=0;
	last=argv.length-1;
	
	if (op.equals("-uniform")) signal2=uniform_parse();
	else if (op.equals("-gaussian")) signal2=gaussian_parse();
	else if (op.equals("-poisson")) signal2=poisson_parse();
	else {
	      throw new InvalidCommandLineException();
			 }
	
  // create a new SignalOutputStream
  SignalOutputStream os = new SignalOutputStream(argv[last]);
  os.write(signal2);
  os.close();

   
   } catch (Exception e) {e.printStackTrace();}
	}
	
	
	private static Signal gaussian_parse() throws IOException, IllegalPBMFormatException, SignalNotSupportedException{
  
	jigl.signal.Signal signal=null;
  String inputfile = param[1];
	Float val = Float.valueOf(param[2]);
	float std = val.floatValue();
  
	SignalInputStream is = new SignalInputStream(inputfile);
	signal = is.read();
	is.close();
  	
	return gaussian(signal,std);

}	

/**Takes a jigl signal and returns a jigl signal with noise following the Gaussian distribution
   @param signal jigl Signal to add noise to
	 @param std standard deviation*/
		
public static Signal gaussian(jigl.signal.Signal signal,float std) throws SignalNotSupportedException{
    if (signal instanceof DiscreteSignal)
		  return gaussian((DiscreteSignal)signal,std); 
		else if (signal instanceof RealSignal)
		 return gaussian((RealSignal)signal,std); 
		else if (signal instanceof ComplexSignal) {
			throw new SignalNotSupportedException();
		}
		return null;
}

/**Takes a DiscreteSignal and returns a DiscreteSignal with noise following the Gaussian distribution
   @param signal DiscreteSignal to add noise to
	 @param std standard deviation*/
public static DiscreteSignal gaussian(DiscreteSignal signal, float std){
    java.util.Random random=new java.util.Random();
    float val=0;
		float choice=0;
		
	   for (int x=0; x<signal.length(); x++)
			 	 {
				  choice=random.nextFloat();
					val=(float)random.nextGaussian();
					val=std*val;
					if (choice>0.5) signal.add(x,(int)val);
					   else signal.subtract(x,(int)val);
				 }
		
   return signal;  

}
/**Takes a RealSignal and returns a RealSignal with noise following the Gaussian distribution
   @param signal RealSignal to add noise to
	 @param std standard deviation*/
public static RealSignal gaussian(RealSignal signal, float std){
    java.util.Random random=new java.util.Random();
    float val=0;
		float choice=0;
		
	   for (int x=0; x<signal.length(); x++)
			  {
				  choice=random.nextFloat();
					val=(float)random.nextGaussian();
					val=std*val;
					if (choice>0.5) signal.add(x,(int)val);
					   else signal.subtract(x,(int)val);
				 }
		
   return signal;  

}

  
	private static Signal uniform_parse() throws IOException, IllegalPBMFormatException, SignalNotSupportedException{
  
	jigl.signal.Signal signal=null;
  String inputfile = param[1];
	Float val = Float.valueOf(param[2]);
	float range = val.floatValue();
  
	
  SignalInputStream is = new SignalInputStream(inputfile);
	signal = is.read();
	is.close();
  
	return uniform(signal,range);

	}	
	
	/**Takes an Signal and returns an Signal with noise following the uniform distribution.
   @param signal jigl Signal to add noise to
	 @param range range (0..255)*/
	public static Signal uniform(jigl.signal.Signal signal,float range) throws SignalNotSupportedException {
    if (signal instanceof DiscreteSignal)
		  return uniform((DiscreteSignal)signal, (int)range); 
		else if (signal instanceof RealSignal)
		  return uniform((RealSignal)signal, range); 
		else if (signal instanceof ComplexSignal) {
			throw new SignalNotSupportedException();
		}
		return null;
 }

 /**Takes a DiscreteSignal and returns a DiscreteSignal with noise following the uniform distribution.
   @param signal DiscreteSignal to add noise to
	 @param range range (0..255)*/
 public static DiscreteSignal uniform(DiscreteSignal signal,int range){
	  java.util.Random random=new java.util.Random();
    int int_val=0;
		float float_val=0;
		float choice=0;
		
	    for (int x=0; x<signal.length(); x++)
			  {
				  choice=random.nextFloat();
					int_val=random.nextInt();
					int_val=int_val%range;
					if (choice>0.5) signal.add(x,int_val);
					   else signal.subtract(x,int_val);
				 }
		
   return signal; 
}

/**Takes a RealSignal and returns a RealSignal with noise following the uniform distribution.
   @param signal RealSignal to add noise to
	 @param range range (0..255)*/
public static RealSignal uniform(RealSignal signal,float range){
	  java.util.Random random=new java.util.Random();
    int int_val=0;
		float float_val=0;
		float choice=0;
		
	  if (signal instanceof RealSignal){
		  for (int x=0; x<signal.length(); x++)
			  
				 {
				  choice=random.nextFloat();
					float_val=random.nextInt();
					float_val=float_val%range;
					if (choice>0.5) signal.add(x,int_val);
					   else signal.subtract(x,int_val);
				 }
		}
   return signal; 
}

 
private static Signal poisson_parse() throws IOException, IllegalPBMFormatException, SignalNotSupportedException{
  jigl.signal.Signal signal=null;
  String inputfile = param[1];
		
  SignalInputStream is = new SignalInputStream(inputfile);
	signal = is.read();
	is.close();
  
	return poisson(signal);

  }	
	
	/**Takes an Signal and returns an Signal with noise following the poisson distribution.
   @param signal Signal to add noise to
	 */
	public static Signal poisson(jigl.signal.Signal signal) throws SignalNotSupportedException {
   if (signal instanceof DiscreteSignal)
		  return poisson((DiscreteSignal)signal); 
		else if (signal instanceof RealSignal)
		  return poisson((RealSignal)signal); 
		else if (signal instanceof ComplexSignal) {
			throw new SignalNotSupportedException();
		}
  return null;
 }
	
/**Takes a DiscreteSignal and returns a DiscreteSignal with noise following the poisson distribution.
   @param signal DiscreteSignal to add noise to
	 */
public static DiscreteSignal poisson(DiscreteSignal signal){
    java.util.Random random=new java.util.Random();
    int val=0;
		float choice=0;
		
	    for (int x=0; x<signal.length(); x++)
			   {
				  val=signal.get(x);
					val=(int)(random.nextGaussian()*java.lang.Math.sqrt(val)+val);
					if (val<0) val=0;
					signal.set(x,val);
				 }
		
   return signal; 
	}
/**Takes a RealSignal and returns a RealSignal with noise following the poisson distribution.
   @param signal DiscreteSignal to add noise to
	 */
public static RealSignal poisson(RealSignal signal){
    java.util.Random random=new java.util.Random();
    float val=0;
		float choice=0;
		
	    for (int x=0; x<signal.length(); x++)
			  {
				  val=signal.get(x);
					val=(int)(random.nextGaussian()*java.lang.Math.sqrt(val)+val);
					if (val<0) val=0;
					signal.set(x,val);
				 }
		
   return signal; 
	}


}

