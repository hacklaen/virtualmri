/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.signal.utils;

import jigl.signal.*;

/** Shifts an signal*/
public class Shift{

private final int NOWRAP=0;
/** Set the shift not to wrap*/
private final int WRAP=1;
/** Sets the shift to wrap*/
private int xoffset=0;
private boolean wrap=false;

/**Constructs a shift
    @param x shift along the x axis
	 @param y shift along the y axis
	 @wrapp NOWRAP= no wrap WRAP=wrap.
*/
public Shift(int x, int wrapp){
  xoffset=x;
	if (wrapp==1) wrap=true;
	
}


private DiscreteSignal apply(DiscreteSignal signal){
  int X=signal.length();
	 //Convert to the appropriate type
	DiscreteSignal temp=new DiscreteSignal(X);
	
	  for(int x = 0; x < X; x++) {
			if (xoffset>0) temp.set((x+xoffset) % X, signal.get(x)); 
			else temp.set((X+xoffset+x) % X, signal.get(x));
		}
		 
	return temp;
  }	


private DiscreteSignal applynw(DiscreteSignal signal){
  int X=signal.length();
	
	 //Convert to the appropriate type
	DiscreteSignal temp=new DiscreteSignal(X);
	 for(int x = 0; x < X; x++) {
			 if ((x+xoffset>=0) && (x+xoffset<X)) temp.set(x, signal.get(x+xoffset)); 
				else temp.set(x,0);
    }
	
	return temp;
}	

private RealSignal apply(RealSignal signal){
  int X=signal.length();
	
	 //Convert to the appropriate type
	RealSignal temp=new RealSignal(X);
	for(int x = 0; x < X; x++) {
			if (xoffset>0) temp.set((x+xoffset) % X, signal.get(x)); 
			else temp.set((X+xoffset+x) % X, signal.get(x));
		}
	return temp;
  }	
	
private RealSignal applynw(RealSignal signal){
  int X=signal.length();
	
	 //Convert to the appropriate type
	RealSignal temp=new RealSignal(X);
	for(int x = 0; x < X; x++) {
			 if ((x+xoffset>=0) && (x+xoffset<X)) temp.set(x, signal.get(x+xoffset)); 
				else temp.set(x,0);
    }
	return temp;
}	


/** Applies  the shift to this signal*/
public Signal apply(Signal signal){
 if (wrap==true){
  if (signal instanceof DiscreteSignal) return apply((DiscreteSignal)signal);
	else if (signal instanceof RealSignal) return apply((RealSignal)signal);
}
 else {
	if (signal instanceof DiscreteSignal) return applynw((DiscreteSignal)signal);
	else if (signal instanceof RealSignal) return applynw((RealSignal)signal);
}
return null;
}
	
	
	
 
}

