/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.signal.utils;
import jigl.signal.*;
import java.lang.*;
import java.util.*;

public class Convolve
{
private SignalKernel kernel=null;


/**Initilizes Convolve for use with integers*/
	 public Convolve(SignalKernel k){
		 kernel=k;
	 }  
	 		
	/** Convolves this signal with the Kernel*/
	public Signal apply(Signal gr)throws SignalNotSupportedException{
	  if (gr instanceof DiscreteSignal) return apply((DiscreteSignal)gr);
	  else if (gr instanceof RealSignal) return apply((RealSignal)gr);
		else throw new SignalNotSupportedException();
	}
			
	private DiscreteSignal apply(DiscreteSignal gr){
	 
		DiscreteSignal signal=new DiscreteSignal(gr.length());
	  int NumX = kernel.length();
		
		int midX = NumX/2;
				
		double sum = 0;
		double sum2= 0;
		int count=0;
		
		// for every pixel in the original signal
			for (int x = 0; x < gr.length(); x++) {

				//Convolve with the kernel
				sum = 0;
				
				for (int i = -midX; i <= midX; i++){
						try {
							sum += gr.get(x+i) * kernel.get(midX+i);
							}
						catch (Exception e){System.out.print("");
						}
					}
				
				signal.set(x,(int)sum);
			}
		return signal;
	}
	
	private RealSignal apply(RealSignal gr){
	 
		RealSignal signal=new RealSignal(gr.length());
	  int NumX = kernel.length();
		
		int midX = NumX/2;
				
		double sum = 0;
		double sum2= 0;
		int count=0;
		
		// for every pixel in the original signal
			for (int x = 0; x < gr.length(); x++) {

				//Convolve with the kernel
				sum = 0;
				
				for (int i = -midX; i <= midX; i++){
						try {
							sum += gr.get(x+i) * kernel.get(midX+i);
							}
						catch (Exception e){System.out.print("");
						}
					}
					signal.set(x,(float)sum);
			}
		return signal;
	}
	
}
