/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image;
import java.util.*;

public class ImageSequence 
{

/**sequence is a sequence of Images*/
private Vector sequence=null;

/**Creates a new ImageSequence*/
public ImageSequence(){
  sequence=new Vector(0);
}

/**Adds an image to the end of a sequence.  Note: Currently only
   GrayImages and RealGrayImages are supported.*/
public void add(jigl.image.Image image) throws InvalidImageForOpException{
  if (image instanceof GrayImage || image instanceof RealGrayImage)
     sequence.addElement(image);
	else throw new InvalidImageForOpException();
}

/**Adds an Image to an <i>location</i> of a sequence*/
public void add(jigl.image.Image image, int location)throws InvalidImageForOpException{
  if (image instanceof GrayImage || image instanceof RealGrayImage)
      sequence.insertElementAt(image,location);
	else throw new InvalidImageForOpException();
}

/**Gets the Image at <i>index</i>*/
public jigl.image.Image get(int index){
  return (jigl.image.Image)sequence.elementAt(index);
}

/**Removes the Image at <i>index</i>*/
public void remove(int index){
  sequence.removeElementAt(index);
}

/** Finds the maximum value over a sequence*/
public float max() throws ColorModelUnknownException, ColorModelNotSupportedException{
  jigl.image.Image image=null;
	GrayImage gimage=null;
	RealGrayImage rgimage=null;
	float tmax=0;
	float max=0;
	for (int a=0; a<sequence.size(); a++)
	  {
		 image=(jigl.image.Image)sequence.elementAt(a);
		 if (image instanceof GrayImage){
			  gimage=ConvertImage.toGray(image);
				tmax=(float)gimage.max();
		 }
		 else if (image instanceof RealGrayImage){
			  rgimage=ConvertImage.toRealGray(image);
				tmax=rgimage.max();
		 }
		 if (max<tmax) max=tmax;	
	  }	 
  return max; 
}

/** Finds the minimum value over a sequence*/
public float min() throws ColorModelUnknownException, ColorModelNotSupportedException{
  jigl.image.Image image=null;
	GrayImage gimage=null;
	RealGrayImage rgimage=null;
	float tmin=0;
	float min=256;
	for (int a=0; a<sequence.size(); a++)
	  {
		 image=(jigl.image.Image)sequence.elementAt(a);
		 if (image instanceof GrayImage){
			  gimage=ConvertImage.toGray(image);
				tmin=(float)gimage.min();
		 }
		 else if (image instanceof RealGrayImage){
			  rgimage=ConvertImage.toRealGray(image);
				tmin=rgimage.min();
		 }
		 if (min>tmin) min=tmin;	
	  }	 
  return min; 
}

/** Scales a Sequence to an arbitrary max/min*/
public ImageSequence scale(float min, float max) throws ColorModelUnknownException, ColorModelNotSupportedException {
    jigl.image.Image image=null;
		GrayImage gimage=null;
		RealGrayImage rgimage=null;
	  float min_all = min();
		float max_all = max();
    float r=0;
		float range = max - min;
    
		// convert to byte depth
		for (int y = 0; y < sequence.size(); y++) {
		    image=get(y);
				rgimage=ConvertImage.toRealGray(image);
				rgimage.subtract(min);
				rgimage.divide(max_all-min_all);
				rgimage.multiply(max-min);
				rgimage.add(min);
				if (image instanceof GrayImage) image=ConvertImage.toGray(rgimage);
				else image=rgimage;		
				}
				
	
				//value = (((r-min)/(max-min)*(int_max-int_min))+int_min);
				
			return this;
	}

/** ByteSizes the range of this sequence to an arbitrary min/max over a sequence
      @gr RealGrayImage*/
	public ImageSequence byteSize() throws ColorModelUnknownException, ColorModelNotSupportedException{
	 	float min = min();
		float max = max();
		RealGrayImage rgimage=null;
		jigl.image.Image image=null;

		float range = max - min;

		// convert to byte depth
		for (int y = 0; y < sequence.size(); y++) {
		    image=get(y);
				rgimage=ConvertImage.toRealGray(image);
				rgimage.subtract(min);
				rgimage.multiply((float)(255.0/range));
				//value = (int)((255.0/range) * ((float)gr.get(x,y) - min));
								
				if (image instanceof GrayImage) image=ConvertImage.toGray(rgimage);
				else image=rgimage;		
			}
		
    return this;
	}
	
	
	/** Returns a subsequence of a sequence
      @param start starting index
			@param end ending index*/
	public ImageSequence subSequence(int start, int end)throws InvalidImageForOpException{
	
	  ImageSequence seq=new ImageSequence();
	  for (int x=start; x<end; x++){
		  seq.add((jigl.image.Image)sequence.elementAt(x));
		}
		return seq;
	}
	
	/** Returns the number of images in this sequence*/
	public int number(){
	  return sequence.size();
	}

}

