/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image.morph;

import jigl.image.*;
import jigl.math.*;
import java.io.*;

public class Dilate implements Morph{

ImageKernel kernel;
int center_x;
int center_y;

/**Initilizes Dilate*/
public Dilate(ImageKernel ker,int x, int y){
	kernel=ker;
	center_x=x;
	center_y=y;
}

/** Dilates this image*/
	public Image apply(Image gr)throws ImageNotSupportedException{
	  if (gr instanceof BinaryImage) return apply((BinaryImage)gr);
	  else throw new ImageNotSupportedException();
	}
	
/** Dilates this image in a Region of Interest*/
	public Image apply(Image gr, ROI r)throws ImageNotSupportedException{
	  if (gr instanceof BinaryImage) return apply((BinaryImage)gr, r);
	  else throw new ImageNotSupportedException();
	}
 
 /** Dilates a Binary GrayImage*/
 public BinaryImage apply(BinaryImage image){
	
	
	BinaryImage image2=(BinaryImage)image.copy();
	int x1=0;
	int y1=0;
	
	for (int x=0; x<image.X(); x++)
		for (int y=0; y<image.Y(); y++) 
		  if (image.get(x,y)>0) 
			  for (int a=0; a<kernel.X(); a++)
			    for (int b=0; b<kernel.Y(); b++)
					  if (kernel.get(a,b)>0){
						   x1=x-a+1;
							 y1=y-b+1;
							 System.out.println(x1+" "+y1);
							 if ((x1<image2.X()) && (y1<image2.Y()) && (x1>=0) && (y1>=0)) image2.set(x1,y1,1);
						}
	return image2;
 }
	
/** Dilates a Binary GrayImage*/
 public BinaryImage apply(BinaryImage image, ROI r){
	
	
	BinaryImage image2=(BinaryImage)image.copy();
	int x1=0;
	int y1=0;
	
	for (int y = r.uy(); y < r.ly(); y++)
			for (int x = r.ux(); x < r.lx(); x++) 
		  if (image.get(x,y)>0) 
			  for (int a=0; a<kernel.X(); a++)
			    for (int b=0; b<kernel.Y(); b++)
					  if (kernel.get(a,b)>0){
						   x1=x-a+1;
							 y1=y-b+1;
							 System.out.println(x1+" "+y1);
							 
						   if ((x1<r.lx()) && (y1<r.ly()) && (x1>=r.ux()) && (y1>=r.ux())) image2.set(x1,y1,1);
						}
	return image2;
 }
	
 	
public static void main(String[] argv) {
  
	try{
	Image image=null;
	Image image2=null;
	Image image3=null;
  String inputfile = argv[0];
	String kernelfile = argv[1];
	
	ImageInputStream is = new ImageInputStream(inputfile);
	image = is.read();
	is.close();
	
	is = new ImageInputStream(kernelfile);
	image2 = is.read();
	is.close();
	
	Integer f_val1 = Integer.valueOf(argv[2]);
  Integer f_val2 = Integer.valueOf(argv[3]);
	int val1=f_val1.intValue();
	int val2=f_val2.intValue();
	
	Dilate dilate=new Dilate((ImageKernel)image2, val1, val2);
	image3=dilate.apply(image);
  
	//put command line stuff here.
	
	// create a new ImageOutputStream
  ImageOutputStream os = new ImageOutputStream(argv[4]);
  os.write(image3);
  os.close();

  } catch (Exception e) {e.printStackTrace();} 
  }
	 
}
