/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image.morph;

import jigl.image.*;
import jigl.math.*;
import java.io.*;

public class GClose implements Morph{

ImageKernel kernel;
int center_x;
int center_y;

/**Initilizes Close
   ker ImageKernel
	 x center x value
	 y center y value*/
public GClose(ImageKernel ker,int x, int y){
	kernel=ker;
	center_x=x;
	center_y=y;
}

/** Closes this image*/
	public Image apply(Image gr)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return apply((GrayImage)gr);
	  else if (gr instanceof RealGrayImage) return apply((RealGrayImage)gr);
		else throw new ImageNotSupportedException();
	}
	
/** Closes a GrayImage*/
 public GrayImage apply(GrayImage image){
	GrayImage image2=(GrayImage)image.copy();
	GDilate d=new GDilate(kernel, center_x, center_y);
	GErode e=new GErode(kernel, center_x, center_y);
	image2=d.apply(image);
	image2=e.apply(image2);
	return image2;
	
 }
	
 /** Closes a RealGrayImage*/
 public RealGrayImage apply(RealGrayImage image){
	RealGrayImage image2=(RealGrayImage)image.copy();
	GDilate d=new GDilate(kernel, center_x, center_y);
	GErode e=new GErode(kernel, center_x, center_y);
	image2=d.apply(image);
	image2=e.apply(image2);
	return image2;
	
 }
	
/** Closes this image in a Region of Interest*/
	public Image apply(Image gr, ROI r)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return apply((GrayImage)gr, r);
	  else if (gr instanceof RealGrayImage) return apply((RealGrayImage)gr, r);
		else throw new ImageNotSupportedException();
	}
	
/** Closes a GrayImage in a Region of Interest*/
 public GrayImage apply(GrayImage image, ROI r){
	GrayImage image2=(GrayImage)image.copy();
	GDilate d=new GDilate(kernel, center_x, center_y);
	GErode e=new GErode(kernel, center_x, center_y);
	image2=d.apply(image, r);
	image2=e.apply(image2, r);
	return image2;
	
 }
	
 /** Closes a RealGrayImage in a Region of Interest*/
 public RealGrayImage apply(RealGrayImage image, ROI r){
	RealGrayImage image2=(RealGrayImage)image.copy();
	GDilate d=new GDilate(kernel, center_x, center_y);
	GErode e=new GErode(kernel, center_x, center_y);
	image2=d.apply(image, r);
	image2=e.apply(image2, r);
	return image2;
	
 }
	
public static void main(String[] argv) {
  
	try{
	Image image=null;
	Image image2=null;
	Image image3=null;
  String inputfile = argv[0];
	String kernelfile = argv[1];
	
	ImageInputStream is = new ImageInputStream(inputfile);
	image = is.read();
	is.close();
	
	is = new ImageInputStream(kernelfile);
	image2 = is.read();
	is.close();
	
	Integer f_val1 = Integer.valueOf(argv[2]);
  Integer f_val2 = Integer.valueOf(argv[3]);
	int val1=f_val1.intValue();
	int val2=f_val2.intValue();
	
	GClose close=new GClose((ImageKernel)image2, val1, val2);
	image3=close.apply(image);
  
	//put command line stuff here.
	
	// create a new ImageOutputStream
  ImageOutputStream os = new ImageOutputStream(argv[4]);
  os.write(image3);
  os.close();

  } catch (Exception e) {e.printStackTrace();} 
  }
	 
}
