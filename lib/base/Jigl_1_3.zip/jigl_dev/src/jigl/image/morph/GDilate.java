/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image.morph;

import jigl.image.*;
import jigl.math.*;
import java.io.*;

public class GDilate implements Morph{

ImageKernel kernel;
int center_x;
int center_y;

/**Initilizes Dilate*/
public GDilate(ImageKernel ker,int x, int y){
	kernel=ker;
	center_x=x;
	center_y=y;
}

/** Dilates this image*/
	public Image apply(Image gr)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return apply((GrayImage)gr);
	  else if (gr instanceof RealGrayImage) return apply((RealGrayImage)gr);
		else throw new ImageNotSupportedException();
	}
 /** Dilates a GrayImage*/
 public GrayImage apply(GrayImage image){
	float[][] temp=new float[kernel.X()][kernel.Y()]; 
	float ntemp=0;
	int max=0;
	
	GrayImage image2=(GrayImage)image.copy();
	
	for (int x=0; x<image.X(); x++){
		for (int y=0; y<image.Y(); y++) {
		  
			for (int a=0; a<kernel.X(); a++)
			  for (int b=0; b<kernel.Y(); b++){
				  if (center_x-a+x<0) temp[a][b]=0;
					else if (center_y-b+y<0) temp[a][b]=0;
					else if (center_x-a+x>image.X()-1) temp[a][b]=0;
					else if (center_y-b+y>image.Y()-1) temp[a][b]=0;
					else temp[a][b]=image.get(center_x-a+x,center_y-b+y);
			}
			
			for (int a=0; a<kernel.X(); a++)
			  for (int b=0; b<kernel.Y(); b++){
				  ntemp=temp[a][b]+kernel.get(a,b);
					if (max<ntemp) max=(int)ntemp;
					//System.out.print(ntemp+" ");
			}
			//System.out.println("At "+x+" "+y+"   set to value "+max);  
		  image2.set(x,y,max);
			max=0;
		 
	 }
  }
	return image2;
 }
	
 /** Dilates a RealGrayImage*/
 public RealGrayImage apply(RealGrayImage image){
 
  float[][] temp=new float[kernel.X()][kernel.Y()]; 
	float ntemp=0;
	float max=0;
	
	RealGrayImage image2=(RealGrayImage)image.copy();
	
	for (int x=0; x<image.X(); x++){
		for (int y=0; y<image.Y(); y++) {
		  
			for (int a=0; a<kernel.X(); a++)
			  for (int b=0; b<kernel.Y(); b++){
				  if (center_x-a+x<0) temp[a][b]=0;
					else if (center_y-b+y<0) temp[a][b]=0;
					else if (center_x-a+x>image.X()-1) temp[a][b]=0;
					else if (center_y-b+y>image.Y()-1) temp[a][b]=0;
					else temp[a][b]=image.get(center_x-a+x,center_y-b+y);
			}
			
			for (int a=0; a<kernel.X(); a++)
			  for (int b=0; b<kernel.Y(); b++){
				  ntemp=temp[a][b]+kernel.get(a,b);
					if (max<ntemp) max=ntemp;
					//System.out.print(ntemp+" ");
			}
			//System.out.println("At "+x+" "+y+"   set to value "+max);  
		  image2.set(x,y,max);
			max=0;
		 
	 }
  }
	return image2;
 }
	
/** Dilates this image in a Region of Interest*/
	public Image apply(Image gr, ROI r)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return apply((GrayImage)gr, r);
	  else if (gr instanceof RealGrayImage) return apply((RealGrayImage)gr, r);
		else throw new ImageNotSupportedException();
	}
 /** Dilates a GrayImage in a Region of Interest*/
 public GrayImage apply(GrayImage image, ROI r){
	float[][] temp=new float[kernel.X()][kernel.Y()]; 
	float ntemp=0;
	int max=0;
	
	GrayImage image2=(GrayImage)image.copy();
	
	for (int x=r.ux(); x<r.lx(); x++){
		for (int y=r.uy(); y<r.ly(); y++) {
		  
			for (int a=0; a<kernel.X(); a++)
			  for (int b=0; b<kernel.Y(); b++){
				  if (center_x-a+x<0) temp[a][b]=0;
					else if (center_y-b+y<0) temp[a][b]=0;
					else if (center_x-a+x>image.X()-1) temp[a][b]=0;
					else if (center_y-b+y>image.Y()-1) temp[a][b]=0;
					else temp[a][b]=image.get(center_x-a+x,center_y-b+y);
			}
			
			for (int a=0; a<kernel.X(); a++)
			  for (int b=0; b<kernel.Y(); b++){
				  ntemp=temp[a][b]+kernel.get(a,b);
					if (max<ntemp) max=(int)ntemp;
					//System.out.print(ntemp+" ");
			}
			//System.out.println("At "+x+" "+y+"   set to value "+max);  
		  image2.set(x,y,max);
			max=0;
		 
	 }
  }
	return image2;
 }
	
 /** Dilates a RealGrayImage in a Region of Interest*/
 public RealGrayImage apply(RealGrayImage image, ROI r){
 
  float[][] temp=new float[kernel.X()][kernel.Y()]; 
	float ntemp=0;
	float max=0;
	
	RealGrayImage image2=(RealGrayImage)image.copy();
	
	for (int x=r.ux(); x<r.lx(); x++){
		for (int y=r.uy(); y<r.ly(); y++) {
		  
			for (int a=0; a<kernel.X(); a++)
			  for (int b=0; b<kernel.Y(); b++){
				  if (center_x-a+x<0) temp[a][b]=0;
					else if (center_y-b+y<0) temp[a][b]=0;
					else if (center_x-a+x>image.X()-1) temp[a][b]=0;
					else if (center_y-b+y>image.Y()-1) temp[a][b]=0;
					else temp[a][b]=image.get(center_x-a+x,center_y-b+y);
			}
			
			for (int a=0; a<kernel.X(); a++)
			  for (int b=0; b<kernel.Y(); b++){
				  ntemp=temp[a][b]+kernel.get(a,b);
					if (max<ntemp) max=ntemp;
					//System.out.print(ntemp+" ");
			}
			//System.out.println("At "+x+" "+y+"   set to value "+max);  
		  image2.set(x,y,max);
			max=0;
		 
	 }
  }
	return image2;
 }
	
public static void main(String[] argv) {
  
	try{
	Image image=null;
	Image image2=null;
	Image image3=null;
  String inputfile = argv[0];
	String kernelfile = argv[1];
	
	ImageInputStream is = new ImageInputStream(inputfile);
	image = is.read();
	is.close();
	
	is = new ImageInputStream(kernelfile);
	image2 = is.read();
	is.close();
	
	Integer f_val1 = Integer.valueOf(argv[2]);
  Integer f_val2 = Integer.valueOf(argv[3]);
	int val1=f_val1.intValue();
	int val2=f_val2.intValue();
	
	GDilate dilate=new GDilate((ImageKernel)image2, val1, val2);
	image3=dilate.apply(image);
  
	//put command line stuff here.
	
	// create a new ImageOutputStream
  ImageOutputStream os = new ImageOutputStream(argv[4]);
  os.write(image3);
  os.close();

  } catch (Exception e) {e.printStackTrace();} 
  }
	 
}
