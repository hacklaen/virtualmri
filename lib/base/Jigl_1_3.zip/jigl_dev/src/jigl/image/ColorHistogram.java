/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */
package jigl.image;

/** A Color Histogram holds a 32x32x32 array that contains the count.
*/
public class ColorHistogram
{
int [][][] data;
  
  public ColorHistogram(ColorImage image){
   int a=0;
   int b=0;
   int[] val=new int[3];
    try{
    
    data=new int[32][32][32];
    for (int h=0; h<32; h++)
      for (int i=0; i<32; i++)
	for (int j=0; j<32; j++)
	  {
	    data[h][i][j]=0;
	  }
    for (int x=0; x<image.X(); x++)
      for (int y=0; y<image.Y(); y++){
        a=x;
	b=y;
	val=image.get(x,y);
	data[val[0]/8][val[1]/8][val[2]/8]++;
      }
    }catch (Exception e) {
      System.out.println(a+" "+b+" "+val[0]+" "+val[1]+" "+val[2]);
    }
  }
  
	/**Returns the count of the colorHistogram at <i>x</i> <i>y</i> <i>z</i>*/
  public int count(int x, int y, int z){
    return data[x][y][z];
  }
  
	/** Returns the mean of the entire ColorHistogram as an int[].*/
  public float[] mean(){
    int[] count=new int[3];
    float[] total=new float[3];
    for (int h=0; h<32; h++)
      for (int i=0; i<32; i++)
				for (int j=0; j<32; j++)
	 			 if (data[h][i][j]!=0){
	  		  count[0]=count[0]+data[h][i][j];
	  		  count[1]=count[0]+data[h][i][j];
	  		  count[2]=count[0]+data[h][i][j];
	  		  total[0]=total[0]+h*data[h][i][j];
	  		  total[1]=total[1]+i*data[h][i][j];
	  		  total[2]=total[2]+j*data[h][i][j];
	  }
    float[] results=new float[3];
    results[0]=total[0]/count[0];
    results[1]=total[1]/count[1];
    results[2]=total[2]/count[2];
    return results;
  }
}
