/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image.levelOps;
import jigl.image.*;

public class LookupTable implements LevelOp
{
private float[] table=null;
private int min=0;
private int max=0;
private int clip_min=0;
private int clip_max=0;

/** Creates a LookupTable 
    @param data an array containing the data to be loaded
		@param start the lowest value 
		@param min_val value for any pixel lower than start
		@param max_val value for any pixel larger than the high
*/
public LookupTable(float[] data, int start, int min_val, int max_val){
  table=data;
	min=start;
	max=data.length;
	clip_min=min_val;
	clip_max=max_val;
}

/** Applies the lookup table to this image*/
	public Image apply(Image gr)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return apply((GrayImage)gr);
	  else if (gr instanceof RealGrayImage) return apply((RealGrayImage)gr);
		else throw new ImageNotSupportedException();
	}
	
/** Applies the lookup table to this image*/
	public Image apply(Image gr, ROI r)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return apply((GrayImage)gr, r);
	  else if (gr instanceof RealGrayImage) return apply((RealGrayImage)gr, r);
		else throw new ImageNotSupportedException();
	}

private GrayImage apply(GrayImage gr){
  
	int val=0;
	
	for (int y = 0; y < gr.Y(); y++) {
			for (int x = 0; x < gr.X(); x++) {
			  val=gr.get(x,y)-min;
			  if (val < 0) gr.set(x,y,clip_min);
				else if (val > max) gr.set(x,y,clip_max);
				else gr.set(x,y,(int)table[val]);
			}
			
  	}
	return gr;
	}		

private RealGrayImage apply(RealGrayImage gr){
  
	float val=0;
	
	for (int y = 0; y < gr.Y(); y++) {
			for (int x = 0; x < gr.X(); x++) {
			  val=(float)gr.get(x,y)-(float)min;
			  if (val < 0) gr.set(x,y,clip_min);
				else if (val > max) gr.set(x,y,clip_max);
				else gr.set(x,y,table[(int)val]);
			}
  	}
	return gr;
	}		
	
private GrayImage apply(GrayImage gr, ROI r){
  
	int val=0;
	
	for (int y = r.uy(); y < r.ly(); y++) {
			for (int x = r.ux(); x < r.lx(); x++) {
			  val=gr.get(x,y)-min;
			  if (val < 0) gr.set(x,y,clip_min);
				else if (val > max) gr.set(x,y,clip_max);
				else gr.set(x,y,(int)table[val]);
			}
  	}
	return gr;
	}		

private RealGrayImage apply(RealGrayImage gr, ROI r){
  
	float val=0;
	
	for (int y = r.uy(); y < r.ly(); y++) {
			for (int x = r.ux(); x < r.lx(); x++) {
			  val=(float)gr.get(x,y)-min;
			  if (val < 0) gr.set(x,y,clip_min);
				else if (val > max) gr.set(x,y,clip_max);
				else gr.set(x,y,table[(int)val]);
			}
  	}
	return gr;
	}		
 
}

