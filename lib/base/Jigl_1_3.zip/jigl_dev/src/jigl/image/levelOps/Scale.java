/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image.levelOps;
import jigl.image.*;
import java.io.*;

/** Performs a Scale operation on an image
*/
public class Scale implements LevelOp{

   int int_min;
	 int int_max;
	 float float_min;
	 float float_max;
   
	 /**Initilizes Scale for use with integers*/
	 public Scale(int min, int max){
		int_min=min;
		int_max=max;
	 }
  
	 /**Initilizes Scale for use with floats*/
	 public Scale(float min, float max){
		float_min=min;
		float_max=max;
	 }
		
	/** Scales the range of this image to an arbitrary min/max*/
	public Image apply(Image gr)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return apply((GrayImage)gr);
	  else if (gr instanceof RealGrayImage) return apply((RealGrayImage)gr);
		else throw new ImageNotSupportedException();
	}
	
	/** Scales the range of this image to an arbitrary min/max
      @gr RealGrayImage*/
	private GrayImage apply(GrayImage gr){
	  if (int_min==0){
		    int_min=(int)float_min;
			  int_max=(int)float_max;
		}
		float min = gr.min();
		float max = gr.max();
    float r=0;
		float range = max - min;

		// convert to byte depth
		float value = 0;
		for (int y = 0; y < gr.Y(); y++) {
			for (int x = 0; x < gr.X(); x++) {
			  r=(float)gr.get(x,y);
				value = (((r-min)/(max-min)*(int_max-int_min))+int_min);
				gr.set(x,y,(short)value);
			}
		}
		
    return gr;
	}
	
	/** Scales the range of this image to an arbitrary min/max 
      @gr RealGrayImage*/
	private RealGrayImage apply(RealGrayImage gr){
	  //if (float_min==0){
		//   float_min=(float)int_min;
	//	 float_max=(float)int_max;
	//	}
	  System.out.println(float_min+"  "+float_max);
		float min = gr.min();
		float max = gr.max();

		float r=0;
		float range = max - min;

		// convert to byte depth
	  float value = 0;
		for (int y = 0; y < gr.Y(); y++) {
			for (int x = 0; x < gr.X(); x++) {
			  r=(float)gr.get(x,y);
				value = (float)((r-min)/(max-min))*(float_max/float_min)+float_min;
				gr.set(x,y,(float)value);
			}
		}
    return gr;
	}
	
public static void main(String[] argv) {
  
	try{
	Image image=null;
  String inputfile = argv[2];
	Image image2=null;
	
	
	ImageInputStream is = new ImageInputStream(inputfile);
	image = is.read();
	is.close();
	
	Float f_val1 = Float.valueOf(argv[0]);
  Float f_val2 = Float.valueOf(argv[1]);
	float val1=f_val1.floatValue();
	float val2=f_val2.floatValue();
	
	Scale scale=new Scale(val1, val2);
	
	image2=scale.apply(image);
  
	// create a new ImageOutputStream
  ImageOutputStream os = new ImageOutputStream(argv[3]);
  os.write(image2);
  os.close();

  } catch (Exception e) {e.printStackTrace();}
  }
	
 /** Scales the range of this image to an arbitrary min/max in a Region of Interest*/
	public Image apply(Image gr, ROI r)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return apply((GrayImage)gr,r);
	  else if (gr instanceof RealGrayImage) return apply((RealGrayImage)gr,r);
		else throw new ImageNotSupportedException();
	}
	
	/** Scales the range of this image to an arbitrary min/max in a Region of Interest
      @gr RealGrayImage*/
	private GrayImage apply(GrayImage gr, ROI ri){
	  if (int_min==0){
		    int_min=(int)float_min;
			  int_max=(int)float_max;
		}
		float min = gr.min(ri);
		float max = gr.max(ri);
    float r=0;
		float range = max - min;

		// convert to byte depth
		float value = 0;
		for (int y = ri.uy(); y < ri.ly(); y++) {
			for (int x = ri.ux(); x < ri.lx(); x++) {
			  r=(float)gr.get(x,y);
				value = (((r-min)/(max-min)*(int_max-int_min))+int_min);
				gr.set(x,y,(short)value);
			}
		}
    return gr;
	}
	
	/** Scales the range of this image to an arbitrary min/max in a Region of Interest
      @gr RealGrayImage*/
	private RealGrayImage apply(RealGrayImage gr, ROI ri){
	  if (float_min==0){
		   float_min=(float)int_min;
			 float_max=(float)int_max;
		}
		float min = gr.min(ri);
		float max = gr.max(ri);

		float r=0;
		float range = max - min;

		// convert to byte depth
	  float value = 0;
		for (int y = ri.uy(); y < ri.ly(); y++) {
			for (int x = ri.ux(); x < ri.lx(); x++) {
			  r=(float)gr.get(x,y);
				value = (float)((r-min)/(max-min))*(float_max/float_min)+float_min;
				gr.set(x,y,(float)value);
			}
		}
    return gr;
	}
}

