/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image.levelOps;
import jigl.image.*;
import java.io.*;

/** Performs a Negate operation on an image
*/
public class Negate implements LevelOp{

      
	 /**Dummy Constructor*/
	 public Negate(){
	 }
  
	/** Negates the values of this image*/
	public Image apply(Image gr)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return apply((GrayImage)gr);
	  else if (gr instanceof RealGrayImage) return apply((RealGrayImage)gr);
		else throw new ImageNotSupportedException();
	}
	
	/** Negates the values of this image
      @gr RealGrayImage*/
	private GrayImage apply(GrayImage gr){
		int value = 0;
		for (int y = 0; y < gr.Y(); y++) {
			for (int x = 0; x < gr.X(); x++) {
				value = gr.get(x,y);
				value = -value;
				gr.set(x,y,(short)value);
			}
		}
    return gr;
	}
	
	/** Negates the range of this image to an arbitrary min/max
      @gr RealGrayImage*/
	private RealGrayImage apply(RealGrayImage gr){
		float value = 0;
		for (int y = 0; y < gr.Y(); y++) {
			for (int x = 0; x < gr.X(); x++) {
				value = gr.get(x,y);
				value = -value;
				gr.set(x,y,value);
			}
		}
    return gr;
	}
	
	public static void main(String[] argv) {
  
	try{
	Image image=null;
  String inputfile = argv[0];
	Image image2=null;
	
	
	ImageInputStream is = new ImageInputStream(inputfile);
	image = is.read();
	is.close();
  
	Negate negate=new Negate();
	
	image2=negate.apply(image);
  
	//put command line stuff here.
	
	// create a new ImageOutputStream
  ImageOutputStream os = new ImageOutputStream(argv[1]);
  os.write(image2);
  os.close();
  } catch (Exception e) {e.printStackTrace();}
   
  }
	/** Negates the values of this image in a Region of Interest*/
	public Image apply(Image gr, ROI r)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return apply((GrayImage)gr,r);
	  else if (gr instanceof RealGrayImage) return apply((RealGrayImage)gr,r);
		else throw new ImageNotSupportedException();
	}
	
	/** Negates the values of this image in a Region of Interest
      @gr RealGrayImage*/
	private GrayImage apply(GrayImage gr, ROI r){
		int value = 0;
		for (int y = r.uy(); y < r.ly(); y++) {
			for (int x = r.ux(); x < r.lx(); x++) {
				value = gr.get(x,y);
				value = -value;
				gr.set(x,y,(short)value);
			}
		}
    return gr;
	}
	
	/** Negates the range of this image to an arbitrary min/max in a Region of Interest
      @gr RealGrayImage*/
	private RealGrayImage apply(RealGrayImage gr, ROI r){
		float value = 0;
		for (int y = r.uy(); y < r.ly(); y++) {
			for (int x = r.ux(); x < r.lx(); x++) {
				value = gr.get(x,y);
				value = -value;
				gr.set(x,y,value);
			}
		}
    return gr;
	}
}

