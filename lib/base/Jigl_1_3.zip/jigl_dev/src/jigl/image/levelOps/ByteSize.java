/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image.levelOps;
import jigl.image.*;
import java.io.*;

/** Performs a ByteSize operation on an image
*/
public class ByteSize implements LevelOp{

     
	 Image im=null;
	
	 /**Initilizes ByteSize for use with integers*/
	 public ByteSize(){
	 }
  
	 	
	/** ByteSizes the range of this image to an arbitrary min/max*/
	public Image apply(Image gr)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return apply((GrayImage)gr);
	  else if (gr instanceof RealGrayImage) return apply((RealGrayImage)gr);
		else throw new ImageNotSupportedException();
	}
		
	/** ByteSizes the range of this image to an arbitrary min/max in a Region of Interest*/
	public Image apply(Image gr, ROI r)throws ImageNotSupportedException{
	   throw new ImageNotSupportedException();
	}
		
	/** ByteSizes the range of this image to an arbitrary min/max
      @gr RealGrayImage*/
	public GrayImage apply(GrayImage gr){
	 	float min = gr.min();
		float max = gr.max();

		float range = max - min;

		// convert to byte depth
		int value = 0;
		for (int y = 0; y < gr.Y(); y++) {
			for (int x = 0; x < gr.X(); x++) {
				value = (int)((255.0/range) * ((float)gr.get(x,y) - min));
				value = 0x00FF & value;
				gr.set(x,y,(short)value);
			}
		}
    return gr;
	}
	
	/** ByteSizes the range of this image to an arbitrary min/max
      @gr RealGrayImage*/
	public RealGrayImage apply(RealGrayImage gr){
	 	float min = gr.min();
		float max = gr.max();

		float range = max - min;

		// convert to byte depth
		float value = 0;
		for (int y = 0; y < gr.Y(); y++) {
			for (int x = 0; x < gr.X(); x++) {
				value = (float)((255.0/range) * (gr.get(x,y) - min));
				value = 0x00FF & (int)value;
				gr.set(x,y,value);
			}
		}
    return gr;
	}
  
		
	public static void main(String[] argv) {
  
	try{
	Image image=null;
  String inputfile = argv[0];
	Image image2=null;
	
	
	ImageInputStream is = new ImageInputStream(inputfile);
	image = is.read();
	is.close();
  
	ByteSize bytesize=new ByteSize();
	
	image2=bytesize.apply(image);
  
	//put command line stuff here.
	
	// create a new ImageOutputStream
  ImageOutputStream os = new ImageOutputStream(argv[1]);
  os.write(image2);
  os.close();
  } catch (Exception e) {e.printStackTrace();}   
  }
	
}

