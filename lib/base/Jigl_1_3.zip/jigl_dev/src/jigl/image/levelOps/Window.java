/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image.levelOps;
import jigl.image.*;
import java.io.*;

/** Performs a Window operation on an image
*/
public class Window implements LevelOp{

   int int_min=0;
	 int int_max=0;
	 float float_min=0;
	 float float_max=0;
   
	 /**Initilizes Window for use with integers*/
	 public Window(int min, int max){
		int_min=min;
		int_max=max;
	 }
  
	 /**Initilizes Window for use with floats*/
	 public Window(float min, float max){
		float_min=min;
		float_max=max;
	 }
  
	 /** Windows the range of this image to an arbitrary min/max*/
	public Image apply(Image gr)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return apply((GrayImage)gr);
	  else if (gr instanceof RealGrayImage) return apply((RealGrayImage)gr);
		else throw new ImageNotSupportedException();
	}
		
	/** Windows the range of this image to an arbitrary min/max
      @gr RealGrayImage*/
	private GrayImage apply(GrayImage gr){
	  if (int_min==0){
		    int_min=(int)float_min;
			  int_max=(int)float_max;
		}
		float value = 0;
		for (int y = 0; y < gr.Y(); y++) {
			for (int x = 0; x < gr.X(); x++) {
				value = gr.get(x,y);
				if (value >= int_max) value=255;
				else if (value <= int_min) value=0;
				else value=(255*((value-int_min)/(int_max-int_min)));
				gr.set(x,y,(short)value);
			}
		}
    return gr;
	}
	
	/** Windows the range of this image to an arbitrary min/max
      @gr RealGrayImage*/
	private RealGrayImage apply(RealGrayImage gr){
	  if (float_min==0){
		   float_min=(float)int_min;
			 float_max=(float)int_max;
		}
		float value = 0;
		for (int y = 0; y < gr.Y(); y++) {
			for (int x = 0; x < gr.X(); x++) {
				value = gr.get(x,y);
				if (value >= float_max) value=255;
				else if (value <= float_min) value=0;
				else value=255*( (value-float_min)/(float_max-float_min) );
				gr.set(x,y,value);
			}
		}
    return gr;
	}
	
public static void main(String[] argv) {
  
	try{
	Image image=null;
  String inputfile = argv[2];
	Image image2=null;
	
	
	ImageInputStream is = new ImageInputStream(inputfile);
	image = is.read();
	is.close();
	
	Float f_val1 = Float.valueOf(argv[0]);
  Float f_val2 = Float.valueOf(argv[1]);
	float val1=f_val1.floatValue();
	float val2=f_val2.floatValue();
	
	Window window=new Window(val1, val2);
	
	image2=window.apply(image);
  
	//put command line stuff here.
	
	// create a new ImageOutputStream
  ImageOutputStream os = new ImageOutputStream(argv[3]);
  os.write(image2);
  os.close();
  } catch (Exception e) {e.printStackTrace();}
   
  }
	
	/** Windows the range of this image to an arbitrary min/max in a Region of Interest*/
	public Image apply(Image gr, ROI r)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return apply((GrayImage)gr, r);
	  else if (gr instanceof RealGrayImage) return apply((RealGrayImage)gr, r);
		else throw new ImageNotSupportedException();
	}
		
	/** Windows the range of this image to an arbitrary min/max in a Region of Interest
      @gr RealGrayImage*/
	private GrayImage apply(GrayImage gr, ROI r){
	  if (int_min==0){
		    int_min=(int)float_min;
			  int_max=(int)float_max;
		}
		float value = 0;
		for (int y = r.uy(); y < r.ly(); y++) {
			for (int x = r.ux(); x < r.lx(); x++) {
				value = gr.get(x,y);
				if (value >= int_max) value=255;
				else if (value <= int_min) value=0;
				else value=(255*((value-int_min)/(int_max-int_min)));
				gr.set(x,y,(short)value);
			}
		}
    return gr;
	}
	
	/** Windows the range of this image to an arbitrary min/max in a Region of Interest
      @gr RealGrayImage*/
	private RealGrayImage apply(RealGrayImage gr, ROI r){
	  if (float_min==0){
		   float_min=(float)int_min;
			 float_max=(float)int_max;
		}
		float value = 0;
		for (int y = r.uy(); y < r.ly(); y++) {
			for (int x = r.ux(); x < r.lx(); x++) {
				value = gr.get(x,y);
				if (value >= float_max) value=255;
				else if (value <= float_min) value=0;
				else value=255*( (value-float_min)/(float_max-float_min) );
				gr.set(x,y,value);
			}
		}
    return gr;
	}
}

