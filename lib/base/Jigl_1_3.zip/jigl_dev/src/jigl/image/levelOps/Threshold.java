/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image.levelOps;
import jigl.image.*;
import java.io.*;
/** Performs a Threshold operation on an image
*/
public class Threshold implements LevelOp{

   int int_max;
	 float float_max;
   
	 /**Initilizes Threshold for use with integers*/
	 public Threshold(int max){
		int_max=max;
	 }
  
	 /**Initilizes Threshold for use with floats*/
	 public Threshold(float max){
		float_max=max;
	 }
		
	/** Thresholds the range of this image to an arbitrary min/max*/
	public Image apply(Image gr)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return apply((GrayImage)gr);
	  else if (gr instanceof RealGrayImage) return apply((RealGrayImage)gr);
		else throw new ImageNotSupportedException();
	}
		
	/** Thresholds the range of this image to an arbitrary min/max
      @gr GrayImage*/
	private GrayImage apply(GrayImage gr){
	  if (int_max==0){
		    int_max=(int)float_max;
		}
		int value = 0;
		for (int y = 0; y < gr.Y(); y++) {
			for (int x = 0; x < gr.X(); x++) {
				value = gr.get(x,y);
				if (value >= int_max) value=255;
				else value = 0;
				gr.set(x,y,(short)value);
			}
		}
    return gr;
	}
	
	/** Thresholds the range of this image to an arbitrary min/max
      @gr RealGrayImage*/
	private RealGrayImage apply(RealGrayImage gr){
	  if (float_max==0){
		    float_max=(float)int_max;
		}
		float value = 0;
		for (int y = 0; y < gr.Y(); y++) {
			for (int x = 0; x < gr.X(); x++) {
				value = gr.get(x,y);
				if (value >= float_max) value=255;
				else value = 0;
				gr.set(x,y,value);
			}
		}
    return gr;
	}
public static void main(String[] argv) {
  
	try{
	Image image=null;
  String inputfile = argv[1];
	Image image2=null;
	
	
	ImageInputStream is = new ImageInputStream(inputfile);
	image = is.read();
	is.close();
	
	Float f_val1 = Float.valueOf(argv[0]);
  float val1=f_val1.floatValue();
		
	Threshold threshold=new Threshold(val1);
	
	image2=threshold.apply(image);
  
	//put command line stuff here.
	
	// create a new ImageOutputStream
  ImageOutputStream os = new ImageOutputStream(argv[2]);
  os.write(image2);
  os.close();

  } catch (Exception e) {e.printStackTrace();} 
  }	
/** Thresholds the range of this image to an arbitrary min/max in a Region of Interest*/
	public Image apply(Image gr, ROI r)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return apply((GrayImage)gr,r);
	  else if (gr instanceof RealGrayImage) return apply((RealGrayImage)gr,r);
		else throw new ImageNotSupportedException();
	}
		
	/** Thresholds the range of this image to an arbitrary min/max in a Region of Interest
      @gr GrayImage*/
	private GrayImage apply(GrayImage gr, ROI r){
	  if (int_max==0){
		    int_max=(int)float_max;
		}
		int value = 0;
		for (int y = r.uy(); y < r.ly(); y++) {
			for (int x = r.ux(); x < r.lx(); x++) {
				value = gr.get(x,y);
				if (value >= int_max) value=255;
				else value = 0;
				gr.set(x,y,(short)value);
			}
		}
    return gr;
	}
	
	/** Thresholds the range of this image to an arbitrary min/max in a Region of Interest
      @gr RealGrayImage*/
	private RealGrayImage apply(RealGrayImage gr, ROI r){
	  if (float_max==0){
		    float_max=(float)int_max;
		}
		float value = 0;
		for (int y = r.uy(); y < r.ly(); y++) {
			for (int x = r.ux(); x < r.lx(); x++) {
				value = gr.get(x,y);
				if (value >= float_max) value=255;
				else value = 0;
				gr.set(x,y,value);
			}
		}
    return gr;
	}
}

