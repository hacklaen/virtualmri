/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image;
import jigl.image.*;
import jigl.signal.*;
import java.io.*;

public class CumulativeHistogram extends Histogram
{
private int[] values=null;
private float min=0;
private float max=0;
private float inc=0;


/**Creates a CumulativeHistogram from a histogram. */
public CumulativeHistogram(Histogram histogram) throws ImageNotSupportedException{
  
	int sum=0;
	
	values=new int[histogram.values.length+1];
	
	min=histogram.min;
	max=histogram.max;
	inc=histogram.inc;
 	try{
	for (int x=0; x < (max-min)+1; x++){
	    values[x]=histogram.values[x]+sum;
			sum=sum+histogram.values[x];
	  }
	}catch (Exception e){}

}

/**Increments a cumalative histogram value.  Please note, all calculations are internal.  
   For Example, suppose min=-20 and max=20, if you want to increment the value at -20 then 
	 pass in -20 <i>not</i> 0.*/
public void increment(int value){
       values[(int)((value-min)/inc)]++;  
}

/**Decrements a cumulative histogram value. Please note, all calculations are internal.  
   For Example, suppose min=-20 and max=20, if you want to decrement the value at -20 then 
	 pass in -20 <i>not</i> 0.*/
public void decrement(int value){
       values[(int)((value-min)/inc)]--;
  
}

/**Counts the number at <i>value</i> Please note, all calculations are internal.  
   For Example, suppose min=-20 and max=20, if you want to get the value at -20 then 
	 pass in -20 <i>not</i> 0.*/
public int  count(int value){
     return values[(int)((value-min)/inc)];
  
  }

/**Returns the length of the CumulativeHistogram*/
public int length(){
  
   return values.length;
	
 }

/** Returns the minimum value*/
public float min(){
  return min;
}

/** Returns the maximum value*/
public float max(){
  return max;
}

/** Returns the incrementation value*/
public float inc(){
  return inc;
}

/** Converts the Cumulative Histogram to a Signal*/
public RealSignal toSignal(){
   RealSignal signal=new RealSignal((int)((max-min)/inc)+1);
   for (int x=0; x<((max-min)/inc); x++){
     signal.set(x,values[x]);
	 }
	 return signal;
}
}  






