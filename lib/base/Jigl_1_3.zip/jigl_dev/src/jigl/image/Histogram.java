/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image;
import jigl.image.*;
import jigl.signal.*;

public class Histogram
{
protected int[] values=null;
protected float min=0;
protected float max=0;
protected float inc=0;

/** Default constructor, does nothing*/
public Histogram(){
}
/**Creates a Histogram from this image.  Only Gray and RealGray images are currently supported*/
public Histogram(Image image, int interval) throws ImageNotSupportedException{
        int number=0;
       
	GrayImage gimage=null;
	RealGrayImage rgimage=null;
	
	if (image instanceof GrayImage){
	    gimage=(GrayImage)image;
	    max=gimage.max();
	    min=gimage.min();
			
			number=(int)(max-min);
			int val=0;
      values=new int[(number/interval)+1];
			  for (int x=0; x < image.X(); x++){
	       for (int y=0; y < image.Y(); y++){
					  val=(gimage.get(x,y)/interval);
						values[(int)(val-min)]=values[(int)(val-min)]+1;
				 }
			}
	}
  else if (image instanceof RealGrayImage){
	    rgimage=(RealGrayImage)image;
	    max=rgimage.max();
	    min=rgimage.min();
			number=(int)(max-min);
			float val=0;
      values=new int[(number/interval)+1];
			  for (int x=0; x < image.X(); x++){
	       for (int y=0; y < image.Y(); y++){
					  val=(rgimage.get(x,y)/interval);
						values[(int)(val-min)]=values[(int)(val-min)]+1;
						
				 }
			}
	}
        else throw new ImageNotSupportedException();
        inc=interval;
			
				
}

/**Creates a Histogram from <i>image</i>, with the given interval
   param int_min minimum value in the histogram
   param int_max maximum value in the histogram */ 
public Histogram(Image image, int interval, int int_min, int int_max) throws ImageNotSupportedException{
        int number=0;
       
	GrayImage gimage=null;
	RealGrayImage rgimage=null;
	
	if (image instanceof GrayImage){
	    gimage=(GrayImage)image;
	    int minval=gimage.min();
	    int maxval=gimage.max();
			max=int_max;
	    min=int_min;
			
			number=(int)(max-min);
			int val=0;
      values=new int[(number/interval)+1];
			  for (int x=0; x < image.X(); x++){
	       for (int y=0; y < image.Y(); y++){
					  if (val>=min && val < max) val=(gimage.get(x,y)/interval);
						else val=0;
						values[(int)(val-min)]=values[(int)(val-min)]+1;
				 }
			}
	}
  else if (image instanceof RealGrayImage){
	    rgimage=(RealGrayImage)image;
	    float minval=gimage.min();
	    float maxval=gimage.max();
			max=int_max;
	    min=int_min;
			number=(int)(max-min);
			float val=0;
      values=new int[(number/interval)+1];
			  for (int x=0; x < image.X(); x++){
	       for (int y=0; y < image.Y(); y++){
					  if (val>=min && val < max) val=(rgimage.get(x,y)/interval);
						else val=0;
						values[(int)(val-min)]=values[(int)(val-min)]+1;
						
				 }
			}
	}
        else throw new ImageNotSupportedException();
        inc=interval;
			
				
}

/**Creates a Histogram from this image over a Region of Interest*/
public Histogram(Image image, int interval, jigl.image.ROI r) throws ImageNotSupportedException{
  int number=0;
	GrayImage gimage=null;
	RealGrayImage rgimage=null;
	
	if (image instanceof GrayImage){
	    gimage=(GrayImage)image;
	    max=gimage.max();
	    min=gimage.min();
      number=(int)(max-min);
	    values=new int[(number/interval)+1];
      for (int x=r.ux(); x < r.lx(); x++){
	      for (int y=r.ux(); y < r.lx(); y++){
		      values[gimage.get(x,y)/interval]=values[gimage.get(x,y)/interval]+1;
		    }
	    }
	}
      else if (image instanceof RealGrayImage){
	    rgimage=(RealGrayImage)image;
	    max=gimage.max();
	    min=gimage.min();
            number=(int)(max-min);
	    values=new int[(number/interval)+1];
      for (int x=r.ux(); x < r.lx(); x++){
	      for (int y=r.ux(); y < r.lx(); y++){
		      values[(int)((rgimage.get(x,y)/interval)+min)]=values[(int)((rgimage.get(x,y)/interval)+min)]+1;
		   }
	   }
	}
      else throw new ImageNotSupportedException(); 
      inc=interval;
}

  /** Creates an empty Histogram of size max-min*/
  public Histogram(int minx, int maxx, int increment){
  
    values=new int[(int)(max-min)];
    min=minx;
    max=maxx;
  }

  /**Increments at the given value. Please note, all calculations are internal.  
   For Example, suppose min=-20 and max=20, if you want to increment the value at -20 then 
	 pass in -20 <i>not</i> 0.*/
  public void increment(int value){
  
     values[(int)((value-min)/inc)]++;  

  }
 
	/**Decrements at the given value. Please note, all calculations are internal.  
   For Example, suppose min=-20 and max=20, if you want to decrement the value at -20 then 
	 pass in -20 <i>not</i> 0.*/
  public void decrement(int value){
  
     values[(int)((value-min)/inc)]--;
  
  }

   /** Returns the count at the given value.  Please note, all calculations are internal.  
   For Example, suppose min=-20 and max=20, if you want to get the value at -20 then 
	 pass in -20 <i>not</i> 0.*/
  public int  count(int value){
 
     return values[(int)((value-min)/inc)];
  
  }

  /** Turns this Histogram into a signal*/
  public RealSignal toSignal(){
   RealSignal signal=new RealSignal((int)((max-min)/inc)+1);
   for (int x=0; x<((max-min)/inc); x++){
     signal.set(x,values[x]);
	 }
	 return signal;
}

/** Returns the minimum value*/
public float min(){
  return min;
}

/** Returns the maximum value*/
public float max(){
  return max;
}

/** Returns the incrementation value*/
public float inc(){
  return inc;
}
  }  






