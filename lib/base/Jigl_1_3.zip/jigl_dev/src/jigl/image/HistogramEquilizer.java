/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image;


import jigl.image.levelOps.*;

/**Equalizes a Histogram*/
public class HistogramEquilizer implements LevelOp
{

private CumulativeHistogram hist=null;
private LookupTable table=null;

/**Takes a JIGL image and prepares a lookup table for equalization*/
public HistogramEquilizer(jigl.image.Image image) throws ImageNotSupportedException{
   hist=new CumulativeHistogram(new Histogram(image, 1));
	 float max=hist.max();
	 float min=hist.min();
	 float[] data=new float[hist.length()+1];
	 for (int x=0; x<hist.length(); x++){
		 	     data[x]=(float)(hist.count(x+(int)min)/(float)hist.count((int)max)*255.0);}
	 table=new LookupTable(data, (int)hist.min(), (int)data[0], (int)data[hist.length()]);
}

/**Returns an equilized version of <i>gr</i>*/
public Image apply(Image gr)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return table.apply(gr);
	  else if (gr instanceof RealGrayImage) return table.apply(gr);
		else throw new ImageNotSupportedException();
	}

/**Returns an equilized region in an image <i>gr</i>*/
public Image apply(Image gr, ROI r)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return table.apply(gr, r);
	  else if (gr instanceof RealGrayImage) return table.apply(gr, r);
		else throw new ImageNotSupportedException();
	}
	


}

