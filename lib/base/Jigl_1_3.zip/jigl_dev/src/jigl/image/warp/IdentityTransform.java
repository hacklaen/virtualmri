/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */


package jigl.image.warp;
import jigl.image.*;
import jigl.*;

import java.awt.image.*;

/** Performs Idenity Warp on a MappedImage*/
public class IdentityTransform implements PointMapper{

  public IdentityTransform(){
	}

  /** Performs the Identity Transformation
	    @param x an array containing the x coordinants
			@param y an array containint the y coordinants
		*/
	public void transform(float[] x, float[] y) throws IllegalArgumentException {
	}

  /** Performs the inverse of the Identity Transformation
	    @param x an array containing the x coordinants
			@param y an array containint the y coordinants
			*/
	public void inverseTransform(float[] x, float[] y) throws IllegalArgumentException {
	}
	
	/** Performs the Identity Transformation
	    @param x an array containing the x coordinants
			@param y an array containint the y coordinants
			@param offset the starting point of the array
			@param the number of points from the <i>offset</i> to apply the transformation*/
	public void transform(float[] x, float[] y, int offset, int count) throws IllegalArgumentException {
	}

  /** Performs the inverse of the Identity Transformation
	    @param x an array containing the x coordinants
			@param y an array containint the y coordinants
			@param offset the starting point of the array
			@param the number of points from the <i>offset</i> to apply the transformation*/
	public void inverseTransform(float[] x, float[] y, int offset, int count) throws IllegalArgumentException {
	}
} // image

