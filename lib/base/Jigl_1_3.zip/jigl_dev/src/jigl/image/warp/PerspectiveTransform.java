/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image.warp;

import jigl.math.*;

public class PerspectiveTransform implements PointMapper {
  protected Matrix matrix;
  protected Matrix inverse=null;
	protected boolean applied_once=false;
	
	/** Creates a Perspective Transform from a two dimensional array*/
  public PerspectiveTransform(double[][] data) {
    matrix = new Matrix(data);
  }
  
	/** Creates a Perspective Transform from a Matrix*/
  public PerspectiveTransform(Matrix m) {
    matrix = m;
  }
  
	/** Performs the Perspective Transformation
	    @param x an array containing the x coordinants
			@param y an array containint the y coordinants
			*/
  public void transform(float[] x, float[] y) throws IllegalArgumentException {
		
		float u, v, w;
		
		if (x.length != y.length)
			throw new IllegalArgumentException();
			
		for (int i = 0; i < x.length; ++i) {
    
    u = (float)(matrix.get(0, 0) * x[i] + matrix.get(1, 0) * y[i] + matrix.get(2, 0));
    v = (float)(matrix.get(0, 1) * x[i] + matrix.get(1, 1) * y[i] + matrix.get(2, 1));
    w = (float)(matrix.get(0, 2) * x[i] + matrix.get(1, 2) * y[i] + matrix.get(2, 2));
    
    x[i] = u / w;
    y[i] = v / w;
	 }
  }
	/** Performs the inverse of the Perspective Transformation
	    @param x an array containing the x coordinants
			@param y an array containint the y coordinants
			*/
	 public void inverseTransform(float[] x, float[] y) throws IllegalArgumentException {
		if (x.length != y.length)
			throw new IllegalArgumentException();
		
		float u, v, w;
    
		if (applied_once==false){
		   IdentityMatrix id=new IdentityMatrix(matrix.nColumns());
			 Matrix tempMatrix=new Matrix(matrix);
			 inverse=tempMatrix.gaussj(id);
			 applied_once=true;
		}
		
    for (int i = 0; i < x.length; ++i) {
    
    u = (float)(matrix.get(0, 0) * x[i] + matrix.get(1, 0) * y[i] + matrix.get(2, 0));
    v = (float)(matrix.get(0, 1) * x[i] + matrix.get(1, 1) * y[i] + matrix.get(2, 1));
    w = (float)(matrix.get(0, 2) * x[i] + matrix.get(1, 2) * y[i] + matrix.get(2, 2));
    
    x[i] = u / w;
    y[i] = v / w;
	 }
  }
/** Performs the Perspective Transformation
	    @param x an array containing the x coordinants
			@param y an array containint the y coordinants
			@param offset the starting point of the array
			@param the number of points from the <i>offset</i> to apply the transformation*/
  public void transform(float[] x, float[] y, int offset, int count) throws IllegalArgumentException {
		
		float u, v, w;
		
		if (x.length != y.length)
			throw new IllegalArgumentException();
			
		final int lastIndex = Math.min(x.length, offset + count);
			
		for (int i = offset; i < lastIndex; ++i) {
    
    u = (float)(matrix.get(0, 0) * x[i] + matrix.get(1, 0) * y[i] + matrix.get(2, 0));
    v = (float)(matrix.get(0, 1) * x[i] + matrix.get(1, 1) * y[i] + matrix.get(2, 1));
    w = (float)(matrix.get(0, 2) * x[i] + matrix.get(1, 2) * y[i] + matrix.get(2, 2));
    
    x[i] = u / w;
    y[i] = v / w;
	 }
  }
	
	/** Performs the inverse of the Perspective Transformation
	    @param x an array containing the x coordinants
			@param y an array containint the y coordinants
			@param offset the starting point of the array
			@param the number of points from the <i>offset</i> to apply the transformation*/
	 public void inverseTransform(float[] x, float[] y, int offset, int count) throws IllegalArgumentException {
		if (x.length != y.length)
			throw new IllegalArgumentException();
		
		float u, v, w;
    
		if (applied_once==false){
		   IdentityMatrix id=new IdentityMatrix(matrix.nColumns());
			 Matrix tempMatrix=new Matrix(matrix);
			 inverse=tempMatrix.gaussj(id);
			 applied_once=true;
		}
		
    final int lastIndex = Math.min(x.length, offset + count);
			
		for (int i = offset; i < lastIndex; ++i) {
    
    u = (float)(matrix.get(0, 0) * x[i] + matrix.get(1, 0) * y[i] + matrix.get(2, 0));
    v = (float)(matrix.get(0, 1) * x[i] + matrix.get(1, 1) * y[i] + matrix.get(2, 1));
    w = (float)(matrix.get(0, 2) * x[i] + matrix.get(1, 2) * y[i] + matrix.get(2, 2));
    
    x[i] = u / w;
    y[i] = v / w;
	 }
  }
}
