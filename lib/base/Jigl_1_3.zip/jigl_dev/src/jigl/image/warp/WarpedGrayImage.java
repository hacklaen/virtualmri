/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */
package jigl.image.warp;
import jigl.image.*;
import jigl.*;

import java.awt.image.*;

/** Warped Image*/
public class WarpedGrayImage implements WarpedImage{

  private InterpolatedGrayImage image=null;
	private PointMapper pointmapper=null;
		
	/*Creates a WarpedGrayImage*/
	public WarpedGrayImage(InterpolatedGrayImage im, PointMapper pm){
    
		image=im;
		pointmapper=pm;
	
	}
	
	/** Gets the value at x, y through the waor*/
	public int get(float x,float y){
	  
		 float[] x1=new float[1];
		 float[] y1=new float[1];
		 x1[0]=x;
		 y1[0]=y;
		 try{
			pointmapper.inverseTransform(x1,y1);
		  return image.interp(x1[0],x1[0]);
		 } catch (Exception e) { return 0; }
	
	}

  


} // image

