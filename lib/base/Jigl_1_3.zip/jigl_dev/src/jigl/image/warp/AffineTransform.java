/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image.warp;

import jigl.math.*;

public class AffineTransform implements PointMapper {
  protected Matrix matrix;
	protected Matrix inverse=null;
	protected boolean applied_once=false;
	
  /** Creates an Affine Transform from a two-dimensional array*/
  public AffineTransform(double[][] data) {
    matrix = new Matrix(data);
  }
  
	/** Creates an Affine Transform from a matrix*/
  public AffineTransform(Matrix m) {
    matrix = m;
  }
  
	/** Performs the Affine Transformation 
	    @param x an array containing the x coordinants
			@param y an array containint the y coordinants*/
  public void transform(float[] x, float[] y) throws IllegalArgumentException {
		if (x.length != y.length)
			throw new IllegalArgumentException();
			
		for (int i = 0; i < x.length; ++i) {
      double u, v;
      
      u = matrix.get(0, 0) * x[i] + matrix.get(1, 0) * y[i] + matrix.get(2, 0);
      v = matrix.get(0, 1) * x[i] + matrix.get(1, 1) * y[i] + matrix.get(2, 1);
    
    	x[i] = (float) u;
      y[i] = (float) v;
    }
 }
 
 /** Performs the Affine Transformation 
	    @param x an array containing the x coordinants
			@param y an array containint the y coordinants
			@param offset the starting point of the array
			@param the number of points from the <i>offset</i> to apply the transformation*/
 public void transform(float[] x, float[] y, int offset, int count)
	throws IllegalArgumentException
 {
		if (x.length != y.length)
			throw new IllegalArgumentException();
	  
		final int lastIndex = Math.min(x.length, offset + count);
			
		for (int i = offset; i < lastIndex; ++i) {
      double u, v;
      
      u = matrix.get(0, 0) * x[i] + matrix.get(1, 0) * y[i] + matrix.get(2, 0);
      v = matrix.get(0, 1) * x[i] + matrix.get(1, 1) * y[i] + matrix.get(2, 1);
    
    	x[i] = (float) u;
      y[i] = (float) v;
    }
 }
 
/** Performs the inverse of the Affine Transformation 
      @param x an array containing the x coordinants
			@param y an array containint the y coordinants
			*/
public void inverseTransform(float[] x, float[] y){
    if (x.length != y.length)
			throw new IllegalArgumentException();
		
		if (applied_once==false){
		   IdentityMatrix id=new IdentityMatrix(matrix.nColumns());
			 Matrix tempMatrix=new Matrix(matrix);
			 inverse=tempMatrix.gaussj(id);
			 applied_once=true;
		}
		
		for (int i = 0; i < x.length; ++i) {
      double u, v;
      
      u = inverse.get(0, 0) * x[i] * inverse.get(1, 0) * y[i] + inverse.get(2, 0);
      v = inverse.get(0, 1) * x[i] * inverse.get(1, 1) * y[i] + inverse.get(2, 1);
    
    	x[i] = (float) u;
      y[i] = (float) v;
    }
}
/** Performs the inverse of the Affine Transformation 
	    @param x an array containing the x coordinants
			@param y an array containint the y coordinants
			@param offset the starting point of the array
			@param the number of points from the <i>offset</i> to apply the transformation*/
public void inverseTransform(float[] x, float[] y, int offset, int count){
    if (x.length != y.length)
			throw new IllegalArgumentException();
		
		if (applied_once==false){
		   IdentityMatrix id=new IdentityMatrix(matrix.nColumns());
			 Matrix tempMatrix=new Matrix(matrix);
			 inverse=tempMatrix.gaussj(id);
			 applied_once=true;
		}
		
		final int lastIndex = Math.min(x.length, offset + count);
			
		for (int i = offset; i < lastIndex; ++i) {
      double u, v;
      
      u = inverse.get(0, 0) * x[i] * inverse.get(1, 0) * y[i] + inverse.get(2, 0);
      v = inverse.get(0, 1) * x[i] * inverse.get(1, 1) * y[i] + inverse.get(2, 1);
    
    	x[i] = (float) u;
      y[i] = (float) v;
    }

}
}
