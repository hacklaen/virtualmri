/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image.warp;
import jigl.image.*;


public class Mapper
{
Image image;
InterpolatedImage interpImg;

/** Mapper applies a transfomation (warp) on an entire image
    @param img the image to apply the transformation
		@param interpolationMethod the way to interpolate (0=NEIGHBOR 1=LINEAR 2=CUBIC)*/
  public Mapper(Image img, int interpolationMethod) throws ImageNotSupportedException{
	 
	 if (img instanceof GrayImage) interpImg=new InterpolatedGrayImage((GrayImage)img);
	 else if (img instanceof RealGrayImage) interpImg=new InterpolatedRealGrayImage((RealGrayImage)img);
	 else if (img instanceof ColorImage) interpImg=new InterpolatedColorImage((ColorImage)img);
	 else if (img instanceof RealColorImage) interpImg=new InterpolatedRealColorImage((RealColorImage)img);
	 else throw new ImageNotSupportedException();
		
	 image=img;
	 interpImg.setInterpolationMethod(interpolationMethod);
	}

  /** Applies the transformation on the entire image through the PointMapper*/
  public Image applyTransformation(PointMapper pointmapper){
	  
	 if (image instanceof GrayImage) {
		    GrayImage img=new GrayImage(image.X(), image.Y());
				InterpolatedGrayImage intImg=(InterpolatedGrayImage)interpImg;
				int value=0;
				float[] x1=new float[1];
				float[] y1=new float[1];
				for (int x=0; x<image.X(); x++)
		      for (int y=0; y<image.Y(); y++){
			      x1[0]=x;
				    y1[0]=y;
				    pointmapper.inverseTransform(x1,y1);
				    try{
						  value=intImg.interp(x1[0],y1[0]);
						  img.set(x,y,value);
						}
						catch (Exception e) {img.set(x,y,0);} 
					}
				return img;
	 }
	 else if (image instanceof RealGrayImage) {
		    RealGrayImage img=new RealGrayImage(image.X(), image.Y());
		    InterpolatedRealGrayImage intImg=(InterpolatedRealGrayImage)interpImg;
				float value=0;
				float[] x1=new float[1];
				float[] y1=new float[1];
	      for (int x=0; x<image.X(); x++)
		      for (int y=0; y<image.Y(); y++){
			      x1[0]=x;
				    y1[0]=y;
				    pointmapper.inverseTransform(x1,y1);
				    try{
						  value=intImg.interp(x1[0],y1[0]);
						  img.set(x,y,value);
						}
						catch (Exception e) {img.set(x,y,0);} 
					}
				return img;		
	 }
	 else if (image instanceof ColorImage) {
		    ColorImage img=new ColorImage(image.X(), image.Y());
				InterpolatedColorImage intImg=(InterpolatedColorImage)interpImg;
				int[] value=null;
				float[] x1=new float[1];
				float[] y1=new float[1];
	      for (int x=0; x<image.X(); x++)
		      for (int y=0; y<image.Y(); y++){
			      x1[0]=x;
				    y1[0]=y;
				    pointmapper.inverseTransform(x1,y1);
				    try{
						  value=intImg.interp(x1[0],y1[0]);
						  img.set(x,y,value);
						}
						catch (Exception e) {img.plane(0).set(x,y,0);
						                     img.plane(1).set(x,y,0);
																 img.plane(2).set(x,y,0);}
					}
				return img;
	 }
	 else if (image instanceof RealColorImage) {
		    RealColorImage img=new RealColorImage(image.X(), image.Y());
        InterpolatedRealColorImage intImg=(InterpolatedRealColorImage)interpImg;
				float[] value=null;
				float[] x1=new float[1];
				float[] y1=new float[1];
	      for (int x=0; x<image.X(); x++)
		      for (int y=0; y<image.Y(); y++){
			      x1[0]=x;
				    y1[0]=y;
				    pointmapper.inverseTransform(x1,y1);
				    try{
						  value=intImg.interp(x1[0],y1[0]);
						  img.set(x,y,value);
						}
						catch (Exception e) {img.plane(0).set(x,y,0);
						                     img.plane(1).set(x,y,0);
																 img.plane(2).set(x,y,0);}
					}
				return img;
	 }
   return null;
	
	}
	
  

}

