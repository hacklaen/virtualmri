/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image;
/** PowerImage takes a complex Image and computes the value at x,y
     by squaring the real plane.*/
     
public class PowerImage extends RealGrayImage
{

/** Constructor that calls super() */
public PowerImage() {
  super();
}

  /**Creates an empty one dimensional of length x*/
	public PowerImage(int x, int y) {
		super(x,y);
	}
	
	/**Creates a one dimensional PowerImage (shallow copy)*/
	public PowerImage(PowerImage image) {
		super(image);
	}

	public PowerImage(ComplexImage image){
	  X=image.X();
		Y=image.Y();
		data=new float[Y][X];
		for (int y=0; y<Y; y++){
		 for (int x=0; x<X; x++){
		   data[y][x]=(float)image.getReal(x,y)*(float)image.getReal(x,y);
			}
    }	
	}


}

