/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image.utils;
import jigl.image.*;
import java.lang.*;
import java.util.*;

public class Convolve
{
private ImageKernel kernel=null;


/**Initilizes Convolve for use with integers*/
	 public Convolve(ImageKernel k){
		 kernel=k;
	 }
  
	 		
	/** Convolves this image with the Kernel*/
	public final Image apply(Image gr)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return apply((GrayImage)gr);
	  else if (gr instanceof RealGrayImage) return apply((RealGrayImage)gr);
		else if (gr instanceof ColorImage) return apply((ColorImage)gr);
		else throw new ImageNotSupportedException();
	}
			
	private final GrayImage apply(GrayImage gr){
	 
		GrayImage image=new GrayImage(gr.X(), gr.Y());
	  int NumX = kernel.X();
		int NumY = kernel.Y();
		int X=gr.X();
	  int Y=gr.Y();
		int midX = NumX/2;
		int midY = NumY/2;
		
		double sum = 0;
		double sum2=0;
		int count=0;
		
		// for every pixel in the original image
		for (int y = 0; y < gr.Y(); y++) 
			for (int x = 0; x < gr.X(); x++) {

				//Convolve with the kernel
				sum = 0;
				
				for (int j = -midY; j <= midY; j++)
					for (int i = -midX; i <= midX; i++){
						if ((y+j>=0) && (x+i>=0) && (y+j<Y) && (x+i<X) && (midY+j>=0) && (midX+i>=0) && (midY+j<NumY) && (midX+i<NumX))
							sum += gr.get((x+i),(y+j)) * kernel.get((midX+i),(midY+j));
						
					}
				image.set(x,y,(int)sum);
			}
		return image;
	}
	
	private final RealGrayImage apply(RealGrayImage gr){
	 RealGrayImage image=new RealGrayImage(gr.X(), gr.Y());
	 int NumX = kernel.X();
	 int NumY = kernel.Y();
	 int X=gr.X();
	 int Y=gr.Y();
		int midX = NumX/2;
		int midY = NumY/2;
		
		double sum = 0;
			
		// for every pixel in the original image
		for (int y = 0; y < gr.Y(); y++) 
			for (int x = 0; x < gr.X(); x++) {

				//Convolve with the kernel
				sum = 0;
				
				for (int j = -midY; j <= midY; j++)
					for (int i = -midX; i <= midX; i++){
						if ((y+j>=0) && (x+i>=0) && (y+j<Y) && (x+i<X) && (midY+j>=0) && (midX+i>=0) && (midY+j<NumY) && (midX+i<NumX))
						
							sum += gr.get((x+i),(y+j)) * kernel.get((midX+i),(midY+j));
						
					}
				image.set(x,y,(float)sum);
			}
		return image;
	}
	
	
	private ColorImage apply(ColorImage gr){
	  ColorImage image=new ColorImage(gr.X(), gr.Y());
		image.setPlane(0,(GrayImage)apply(gr.plane(0)));
		image.setPlane(1,(GrayImage)apply(gr.plane(1)));
		image.setPlane(2,(GrayImage)apply(gr.plane(2)));
	  return image;
	}
	
	
	private ColorImage apply(ColorImage gr, ROI r){
	  ColorImage image=new ColorImage(gr.X(), gr.Y());
		image.setPlane(0,(GrayImage)apply(gr.plane(0),r));
		image.setPlane(1,(GrayImage)apply(gr.plane(1),r));
		image.setPlane(2,(GrayImage)apply(gr.plane(2),r));
	  return image;
	}
	
	private RealColorImage apply(RealColorImage gr){
	  RealColorImage image=new RealColorImage(gr.X(), gr.Y());
		image.setPlane(0,(RealGrayImage)apply(gr.plane(0)));
		image.setPlane(1,(RealGrayImage)apply(gr.plane(1)));
		image.setPlane(2,(RealGrayImage)apply(gr.plane(2)));
	  return image;
	}
	
	
	private RealColorImage apply(RealColorImage gr, ROI r){
	  RealColorImage image=new RealColorImage(gr.X(), gr.Y());
		image.setPlane(0,(RealGrayImage)apply(gr.plane(0),r));
		image.setPlane(1,(RealGrayImage)apply(gr.plane(1),r));
		image.setPlane(2,(RealGrayImage)apply(gr.plane(2),r));
	  return image;
	}
	
	/** Applys a threaded version for faster execution on dual processor machines.*/
	public ColorImage applyThreaded(ColorImage gr){
	  
	  ColorImage image=new ColorImage(gr.X(), gr.Y());
	  Threader th0=new Threader(gr.plane(0), kernel);
		th0.start();
		
	  Threader th1=new Threader(gr.plane(1), kernel);
		th1.start();
		
	  Threader th2=new Threader(gr.plane(2), kernel);
		th2.start();
		
		try{
	   th0.runner.join();
	   th1.runner.join();
	   th2.runner.join();
		} catch (Exception e){}
		
		image.setPlane(0,th0.img);
		image.setPlane(1,th1.img);
		image.setPlane(2,th2.img);
	 
	return image;
	}
	
	/**Convolves this image with in a Region of Interest*/
	public Image apply(Image gr, ROI r)throws ImageNotSupportedException{
	  if (gr instanceof GrayImage) return apply((GrayImage)gr,r);
	  else if (gr instanceof RealGrayImage) return apply((RealGrayImage)gr,r);
		else throw new ImageNotSupportedException();
	}
			
	private GrayImage apply(GrayImage gr,ROI r){
	  GrayImage image=(GrayImage)gr.copy();
	  int NumX = kernel.X();
		int NumY = kernel.Y();
		int X=gr.X();
	  int Y=gr.Y();
		int midX = NumX/2;
		int midY = NumY/2;
		
		double sum = 0;
		double sum2=0;
		int count=0;
		
		// for every pixel in the original image
		for (int y = r.uy(); y < r.ly(); y++) 
			for (int x = r.ux(); x < r.lx(); x++) {

				//Convolve with the kernel
				sum = 0;
				
				for (int j = -midY; j <= midY; j++)
					for (int i = -midX; i <= midX; i++){
						try {
							sum += gr.get((x+i),(y+j)) * kernel.get((midX+i),(midY+j));
							}
						catch (Exception e){System.out.print("");
						}
					}
				
				image.set(x,y,(int)sum);
			}
		return image;
	}
	
	
	private RealGrayImage apply(RealGrayImage gr, ROI r){
	 RealGrayImage image=(RealGrayImage)gr.copy();
	 int NumX = kernel.X();
	 int NumY = kernel.Y();
	 int X=gr.X();
	 int Y=gr.Y();
	 int midX = NumX/2;
	 int midY = NumY/2;
		
		double sum = 0;
			
		// for every pixel in the original image
		for (int y = r.uy(); y < r.ly(); y++) 
			for (int x = r.ux(); x < r.lx(); x++) {

				//Convolve with the kernel
				sum = 0;
				
				for (int j = -midY; j <= midY; j++)
					for (int i = -midX; i <= midX; i++){
						try {
							sum += gr.get((x+i),(y+j)) * kernel.get((midX+i),(midY+j));
							}
						catch (Exception e){System.out.print("");
						}
					}
				
				image.set(x,y,(float)sum);
			}
		return image;
	}
	
	/** allows for command line options.  The first is the image, second is the kernel and 
	    third is the outputfile.*/
	public static void main(String[] argv) {
  
	try{
	Image image=null;
  String inputfile = argv[0];
	RealGrayImage image2=null;
	String inputfile2 = argv[1];
	
	ImageInputStream is = new ImageInputStream(inputfile);
	image = is.read();
	is.close();
	
	is = new ImageInputStream(inputfile2);
	image2 = (RealGrayImage)is.read();
	is.close();

	Convolve convolve=new Convolve((ImageKernel)image2);
  image=convolve.apply(image);
  
	//put command line stuff here.
	
	// create a new ImageOutputStream
  ImageOutputStream os = new ImageOutputStream(argv[3]);
  os.write(image);
  os.close();

  } catch (Exception e) {e.printStackTrace();} 
  }
}

class Threader implements Runnable{

Thread runner=null;
GrayImage img=null;
Convolve conv=null;

public Threader(GrayImage image, ImageKernel k){
  img=image;
	conv=new Convolve(k);
	}

public void start(){
  runner = new Thread(this);
	runner.start();
}

public void run(){
 try{ 
	img=(GrayImage)conv.apply(img);
 } catch (Exception e) {}
}

}
