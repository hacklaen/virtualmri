/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image.utils;
import java.util.*;
import jigl.*;
import jigl.image.*;
import java.lang.*;
import java.io.*;

/**Noise add various noise distributions to all the supported JIGL
image classes <I><U>except</U></I> ComplexImage.
<BR>&nbsp;
<BR>&nbsp;
<TABLE BORDER WIDTH="100%" BGCOLOR="#CCCCCC" >
<TR>
<TD COLSPAN="3" BGCOLOR="#FFFF00">
<CENTER><FONT SIZE=+1>Noise Command Lines</FONT></CENTER>
</TD>
</TR>

<TR>
<TD BGCOLOR="#00B6F2">
<CENTER>&nbsp;<B>Noise Distribution</B></CENTER>
</TD>

<TD BGCOLOR="#00B6F2">
<CENTER><B>Command Line</B></CENTER>
</TD>

<TD BGCOLOR="#00B6F2">
<CENTER><B>Notes</B></CENTER>
</TD>
</TR>

<TR>
<TD WIDTH="30" BGCOLOR="#CCCCCC">&nbsp; Uniform</TD>

<TD WIDTH="90">-uniform &lt;input file> &lt;range> &lt;output file></TD>

<TD ROWSPAN="3" WIDTH="200">&nbsp; *&lt;range> is an integer value for
a GrayImage, and ColorImage, float otherwise.

<P>&nbsp; *&lt;standard deviation> is always a float value.

<P>&nbsp; *filenames need the full extension.&nbsp;
<BR>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -ex. D:\pictures\mine\test1.pgm</TD>
</TR>

<TR>
<TD WIDTH="60">&nbsp; Gaussian</TD>

<TD WIDTH="90">-gaussian &lt;input file> &lt;standard deviation> &lt;output
file></TD>
</TR>

<TR>
<TD WIDTH="60">&nbsp; Poisson</TD>

<TD WIDTH="190">-poisson &lt;input file> &lt;output file></TD>
</TR>
</TABLE>
&nbsp;
<BR>Example Command Lines:

<P>&nbsp;&nbsp;&nbsp; <FONT FACE="Courier New,Courier"><FONT SIZE=-1>-uniform
D:\pictures\test1.pgm 35 D:\pictures\output\test_out.pgm</FONT></FONT><FONT FACE="Courier New,Courier"><FONT SIZE=-1></FONT></FONT>

<P><FONT FACE="Courier New,Courier"><FONT SIZE=-1>&nbsp; -gaussian D:\pictures\test1.pgm
92.1 D:\pictures\output\test_out.pgm</FONT></FONT><FONT FACE="Courier New,Courier"><FONT SIZE=-1></FONT></FONT>

<P><FONT FACE="Courier New,Courier"><FONT SIZE=-1>&nbsp; -poisson D:\pictures\test1.pgm
D:\pictures\output\test_out.pgm</FONT></FONT>
*/
public class Noise
{
private static String[] param=null;

public static void main(String[] argv) {
  
	
	int last=0;
  param=argv;
  
	try{
	String op=argv[0];
	jigl.image.Image image2=null;
	int outfile=0;
	last=argv.length-1;
	
	if (op.equals("-uniform")) image2=uniform_parse();
	else if (op.equals("-gaussian")) image2=gaussian_parse();
	else if (op.equals("-poisson")) image2=poisson_parse();
	else {
	      throw new InvalidCommandLineException();
			 }
	
  // create a new ImageOutputStream
  ImageOutputStream os = new ImageOutputStream(argv[last]);
  os.write(image2);
  os.close();

   
   } catch (Exception e) {e.printStackTrace();}
	}
	
	
	private static Image gaussian_parse() throws InterruptedException, IOException, IllegalPBMFormatException, ImageNotSupportedException{
  
	jigl.image.Image image=null;
  String inputfile = param[1];
	Float val = Float.valueOf(param[2]);
	float std = val.floatValue();
  
	ImageInputStream is = new ImageInputStream(inputfile);
	image = is.read();
	is.close();
  	
	return gaussian(image,std);

}	

/**Takes a jigl image and returns a jigl image with noise following the Gaussian distribution
   @param image jigl Image to add noise to
	 @param std standard deviation*/
		
public static Image gaussian(jigl.image.Image image,float std) throws ImageNotSupportedException{
    if (image instanceof GrayImage)
		  return gaussian((GrayImage)image,std); 
		else if (image instanceof RealGrayImage)
		 return gaussian((RealGrayImage)image,std); 
		else if (image instanceof ColorImage)
		  return gaussian((ColorImage)image,std); 
		else if (image instanceof RealColorImage)
		  return gaussian((RealColorImage)image,std);
		else if (image instanceof ComplexImage) {
			throw new ImageNotSupportedException();
		}
		return null;
}

/**Takes a GrayImage and returns a GrayImage with noise following the Gaussian distribution
   @param image GrayImage to add noise to
	 @param std standard deviation*/
public static GrayImage gaussian(GrayImage image, float std){
    java.util.Random random=new java.util.Random();
    float val=0;
		float choice=0;
		
	   for (int x=0; x<image.X(); x++)
			 for (int y=0; y<image.Y(); y++)
				 {
				  choice=random.nextFloat();
					val=(float)random.nextGaussian();
					val=std*val;
					if (choice>0.5) image.add(x,y,(int)val);
					   else image.subtract(x,y,(int)val);
				 }
		
   return image;  

}
/**Takes a RealGrayImage and returns a RealGrayImage with noise following the Gaussian distribution
   @param image RealGrayImage to add noise to
	 @param std standard deviation*/
public static RealGrayImage gaussian(RealGrayImage image, float std){
    java.util.Random random=new java.util.Random();
    float val=0;
		float choice=0;
		
	   for (int x=0; x<image.X(); x++)
			 for (int y=0; y<image.Y(); y++)
				 {
				  choice=random.nextFloat();
					val=(float)random.nextGaussian();
					val=std*val;
					if (choice>0.5) image.add(x,y,val);
					   else image.subtract(x,y,val);
				 }
		
   return image;  

}
/**Takes a GrayImage and returns a GrayImage with noise following the Gaussian distribution.
   This is done by performing adding noise to each plane seperately.
   @param image ColorImage to add noise to
	 @param std standard deviation*/
public static ColorImage gaussian(ColorImage image, float std){
    
		image.setPlane(0,gaussian(image.plane(0),std));
    image.setPlane(1,gaussian(image.plane(1),std));
		image.setPlane(2,gaussian(image.plane(2),std));
		
		return image;
}

/**Takes a RealColorImage and returns a RealColorImage with noise following the Gaussian distribution.
   This is done by performing adding noise to each plane seperately.
   @param image RealColorImage to add noise to
	 @param std standard deviation*/
public static RealColorImage gaussian(RealColorImage image, float std){
    
		image.setPlane(0,gaussian(image.plane(0),std));
    image.setPlane(1,gaussian(image.plane(1),std));
		image.setPlane(2,gaussian(image.plane(2),std));
		
		return image;
}
  
  
	private static Image uniform_parse() throws InterruptedException,IOException, IllegalPBMFormatException, ImageNotSupportedException{
  
	jigl.image.Image image=null;
  String inputfile = param[1];
	Float val = Float.valueOf(param[2]);
	float range = val.floatValue();
  
	
  ImageInputStream is = new ImageInputStream(inputfile);
	image = is.read();
	is.close();
  
	return uniform(image,range);

	}	
	
	/**Takes an Image and returns an Image with noise following the uniform distribution.
   @param image jigl Image to add noise to
	 @param range range (0..255)*/
	public static Image uniform(jigl.image.Image image,float range) throws ImageNotSupportedException {
    if (image instanceof GrayImage)
		  return uniform((GrayImage)image, (int)range); 
		else if (image instanceof RealGrayImage)
		  return uniform((RealGrayImage)image, range); 
		else if (image instanceof ColorImage)
		  return uniform((ColorImage)image, (int)range); 
		else if (image instanceof RealColorImage)
		  return uniform((RealColorImage)image, range);
		else if (image instanceof ComplexImage) {
			throw new ImageNotSupportedException();
		}
		return null;
 }

 /**Takes a GrayImage and returns a GrayImage with noise following the uniform distribution.
   @param image GrayImage to add noise to
	 @param range range (0..255)*/
 public static GrayImage uniform(GrayImage image,int range){
	  java.util.Random random=new java.util.Random();
    int int_val=0;
		float float_val=0;
		float choice=0;
		
	    for (int x=0; x<image.X(); x++)
			  for (int y=0; y<image.Y(); y++)
				 {
				  choice=random.nextFloat();
					int_val=random.nextInt();
					int_val=int_val%range;
					if (choice>0.5) image.add(x,y,int_val);
					   else image.subtract(x,y,int_val);
				 }
		
   return image; 
}

/**Takes a RealGrayImage and returns a RealGrayImage with noise following the uniform distribution.
   @param image RealGrayImage to add noise to
	 @param range range (0..255)*/
public static RealGrayImage uniform(RealGrayImage image,float range){
	  java.util.Random random=new java.util.Random();
    int int_val=0;
		float float_val=0;
		float choice=0;
		
	  if (image instanceof RealGrayImage){
		  for (int x=0; x<image.X(); x++)
			  for (int y=0; y<image.Y(); y++)
				 {
				  choice=random.nextFloat();
					float_val=random.nextFloat();
					float_val=float_val*range;
					if (choice>0.5) image.add(x,y,float_val);
					   else image.subtract(x,y,float_val);
				 }
		}
   return image; 
}

 /**Takes a ColorImage and returns a ColorImage with noise following the uniform distribution.
    This is done by adding noise to each plane seperately.
		@param image ColorImage to add noise to
	  @param range range (0..255)*/
 public static ColorImage uniform(ColorImage image, int range){
    
		image.setPlane(0,uniform(image.plane(0),range));
		image.setPlane(1,uniform(image.plane(1),range));
		image.setPlane(2,uniform(image.plane(2),range));
			
		return image;
}

/**Takes a ColorImage and returns a ColorImage with noise following the uniform distribution.
    This is done by adding noise to each plane seperately.
		@param image ColorImage to add noise to
	  @param range range (0..255)*/
public static RealColorImage uniform(RealColorImage image, float range){
    
		image.setPlane(0,uniform(image.plane(0),range));
		image.setPlane(1,uniform(image.plane(1),range));
		image.setPlane(2,uniform(image.plane(2),range));
		
		return image;
}

	private static Image poisson_parse() throws InterruptedException, IOException, IllegalPBMFormatException, ImageNotSupportedException{
  jigl.image.Image image=null;
  String inputfile = param[1];
		
  ImageInputStream is = new ImageInputStream(inputfile);
	image = is.read();
	is.close();
  
	return poisson(image);

  }	
	
	/**Takes an Image and returns an Image with noise following the poisson distribution.
   @param image Image to add noise to
	 */
	public static Image poisson(jigl.image.Image image) throws ImageNotSupportedException {
   if (image instanceof GrayImage)
		  return poisson((GrayImage)image); 
		else if (image instanceof RealGrayImage)
		  return poisson((RealGrayImage)image); 
		else if (image instanceof ColorImage)
		 return poisson((ColorImage)image); 
		else if (image instanceof RealColorImage)
		  return poisson((RealColorImage)image);
		else if (image instanceof ComplexImage) {
			throw new ImageNotSupportedException();
		}
  return null;
 }
	
/**Takes a GrayImage and returns a GrayImage with noise following the poisson distribution.
   @param image GrayImage to add noise to
	 */
public static GrayImage poisson(GrayImage image){
    java.util.Random random=new java.util.Random();
    int val=0;
		float choice=0;
		
	    for (int x=0; x<image.X(); x++)
			  for (int y=0; y<image.Y(); y++)
				 {
				  val=image.get(x,y);
					val=(int)(random.nextGaussian()*java.lang.Math.sqrt(val)+val);
					if (val<0) val=0;
					image.set(x,y,val);
				 }
		
   return image; 
	}
/**Takes a RealGrayImage and returns a RealGrayImage with noise following the poisson distribution.
   @param image GrayImage to add noise to
	 */
public static RealGrayImage poisson(RealGrayImage image){
    java.util.Random random=new java.util.Random();
    float val=0;
		float choice=0;
		
	    for (int x=0; x<image.X(); x++)
			  for (int y=0; y<image.Y(); y++)
				 {
				  val=image.get(x,y);
					val=(float)(random.nextGaussian()*java.lang.Math.sqrt(val)+val);
					if (val<0) val=0;
					image.set(x,y,val);
				 }
		
   return image; 
	}
/**Takes a ColorImage and returns a ColorImage with noise following the poisson distribution.
   This is done by performing adding noise to each plane seperately.
   @param image ColorImage to add noise to
	 */
public static ColorImage poisson(ColorImage image){
    image.setPlane(0,poisson(image.plane(0)));
		image.setPlane(1,poisson(image.plane(1)));
		image.setPlane(2,poisson(image.plane(2)));
	return image;
}
/**Takes a RealColorImage and returns a RealColorImage with noise following the poisson distribution.
   This is done by performing adding noise to each plane seperately.
   @param image RealColorImage to add noise to
	 */
public static RealColorImage poisson(RealColorImage image){
		image.setPlane(0,poisson(image.plane(0)));
		image.setPlane(1,poisson(image.plane(1)));
		image.setPlane(2,poisson(image.plane(2)));
		
		return image;
}

}

