/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

package jigl.image;
import jigl.*;

import java.awt.image.*;

/**
   A color image is a set of three gray image planes. <P>
   ColorImage implements Image
   InterpolatedColorImage extends ColorImage
 */

public class InterpolatedColorImage extends ColorImage implements InterpolatedImage {	

	// interpolation
	/**Nearest neighbor constant*/
	public static final int NEIGHBOR = 0;
	/**Linear Interpolation constant*/
	public static final int LINEAR   = 1;
	/**Bicubic constant*/
	public static final int CUBIC    = 2;
	/**The interpolation method that will be used.  Default= NEIGHBOR*/
	protected int interpolationMethod = NEIGHBOR;
	

	/*
		 constructors
	*/
	
	/** creates an empty color image */
	public InterpolatedColorImage() {
		X = 0;
		Y = 0;
		plane[0] = null;
		plane[1] = null;
		plane[2] = null;
	}
	
	
	
	/** creates a color image of dimension x,y */
	public InterpolatedColorImage(int x, int y) {
		X = x;
		Y = y;
		plane[0] = new InterpolatedGrayImage(X, Y);
		plane[1] = new InterpolatedGrayImage(X, Y);
		plane[2] = new InterpolatedGrayImage(X, Y);
	}
	
	/** creates a color image that is a shallow copy of img */
	public InterpolatedColorImage(ColorImage img) {
		super(img);
		plane[0] = new InterpolatedGrayImage(img.plane(0));
		plane[1] = new InterpolatedGrayImage(img.plane(1));
		plane[2] = new InterpolatedGrayImage(img.plane(2));
	}

	/** creates a color image that is a shallow copy of img */
	public InterpolatedColorImage(InterpolatedColorImage img) {
		super(img);
		interpolationMethod = img.getInterpolationMethod();
	}

	/** deep copy */
	public Image copy() {
		InterpolatedColorImage c = new InterpolatedColorImage(X, Y);
		c.setInterpolationMethod(interpolationMethod);
		for(int y = 0; y < Y; y++) {
			for(int x = 0; x < X; x++) {
				c.plane[0].set(x,y,plane[0].get(x,y));
				c.plane[1].set(x,y,plane[1].get(x,y));
				c.plane[2].set(x,y,plane[2].get(x,y));
			}
		}
		return c;
	}
	
	/** set the p plane to image pl: a shallow copy */
	public void setPlane(int p, GrayImage pl) {
		plane[p] = new InterpolatedGrayImage(pl);
	}


	/*
		 interpolation routines
		 
		 three different methods are available: <P>
		 replication, linear interpolation and cubic interpolation
	*/

	/** the the current interpolation method */
	public int getInterpolationMethod() {
		return interpolationMethod;
	}

	/** set the interpolation method <P>
			There are three possibilities: Nearest Neighbor, Linear or Cubic.
	*/			
	public void setInterpolationMethod(int m) {
		if(m == NEIGHBOR || m == LINEAR || m == CUBIC) {
			interpolationMethod = m;
			((InterpolatedGrayImage)plane[0]).setInterpolationMethod(m);
			((InterpolatedGrayImage)plane[1]).setInterpolationMethod(m);
			((InterpolatedGrayImage)plane[2]).setInterpolationMethod(m);
		}
	}

	/** return the interpolated triplet at x */
	public int[] interp(double x) {
		int[] color = new int[3];
		color[0] = ((InterpolatedGrayImage)plane[0]).interp(x);
		color[1] = ((InterpolatedGrayImage)plane[1]).interp(x);
		color[2] = ((InterpolatedGrayImage)plane[2]).interp(x);
		return color;
	}
	
	/** return the interpolated triplet at x,y */
	public int[] interp(double x, double y) {
		int[] color = new int[3];
		color[0] = ((InterpolatedGrayImage)plane[0]).interp(x,y);
		color[1] = ((InterpolatedGrayImage)plane[1]).interp(x,y);
		color[2] = ((InterpolatedGrayImage)plane[2]).interp(x,y);
		return color;
	}
	
	/** add the triplet to the surrounding area */
	public void accum(double x, int[] value) {
		((InterpolatedGrayImage)plane[0]).accum(x,value[0]);
		((InterpolatedGrayImage)plane[1]).accum(x,value[1]);
		((InterpolatedGrayImage)plane[2]).accum(x,value[2]);
	}
	
	/** add the triplet to the surrounding area */
	public void accum(double x, double y, int[] value) {
		((InterpolatedGrayImage)plane[0]).accum(x,y,value[0]);
		((InterpolatedGrayImage)plane[1]).accum(x,y,value[1]);
		((InterpolatedGrayImage)plane[2]).accum(x,y,value[2]);
	}
	
	/** spread the triplet in the surrounding area */
	public void splat(double x, int[] value) {
		((InterpolatedGrayImage)plane[0]).splat(x,value[0]);
		((InterpolatedGrayImage)plane[1]).splat(x,value[1]);
		((InterpolatedGrayImage)plane[2]).splat(x,value[2]);
	}
	
	/** spread the triplet in the surrounding area */
	public void splat(double x, double y, int[] value) {
		((InterpolatedGrayImage)plane[0]).splat(x,y,value[0]);
		((InterpolatedGrayImage)plane[1]).splat(x,y,value[1]);
		((InterpolatedGrayImage)plane[2]).splat(x,y,value[2]);
	}
	
}
