/*JIGL--Java Imaging and Graphics Library
Copyright (C)1999 Brigham Young University

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

A copy of the GNU Library General Public Licence is contained in 
/jigl/licence.txt */

/**
   Interpolated version of a RealColorImage
   
   InterpolatedRealColorImage extends RealColorImage
 */

package jigl.image;
import jigl.*;

import java.awt.image.*;

public class InterpolatedRealColorImage extends RealColorImage implements InterpolatedImage {	

	// interpolation
	/**Nearest neighbor constant*/
	public static final int NEIGHBOR = 0;
	/**Linear Interpolation constant*/
	public static final int LINEAR   = 1;
	/**Bicubic constant*/
	public static final int CUBIC    = 2;
	/**The interpolation method that will be used.  Default= NEIGHBOR*/
	protected int interpolationMethod = NEIGHBOR;

	/*
		 constructors
	*/
	
	/** creates an empty color image */
	public InterpolatedRealColorImage() {
		X = 0;
		Y = 0;
		plane[0] = null;
		plane[1] = null;
		plane[2] = null;
	}
	
	public InterpolatedRealColorImage(RealColorImage img) {
		super(img);
		plane[0] = new InterpolatedRealGrayImage(img.plane(0));
		plane[1] = new InterpolatedRealGrayImage(img.plane(1));
		plane[2] = new InterpolatedRealGrayImage(img.plane(2));
	}
	
	/** creates a color image of dimension x,y */
	public InterpolatedRealColorImage(int x, int y) {
		X = x;
		Y = y;
		plane[0] = new InterpolatedRealGrayImage(X, Y);
		plane[1] = new InterpolatedRealGrayImage(X, Y);
		plane[2] = new InterpolatedRealGrayImage(X, Y);
	}
	
	/** creates a color image that is a shallow copy of img */
	public InterpolatedRealColorImage(InterpolatedRealColorImage img) {
		X = img.X();
		Y = img.Y();
		interpolationMethod = img.getInterpolationMethod();
		plane[0] = img.plane(1);
		plane[1] = img.plane(2);
		plane[2] = img.plane(3);
	}

	/** deep copy */
	public Image copy() {
		InterpolatedRealColorImage c = new InterpolatedRealColorImage(X, Y);
		c.setInterpolationMethod(interpolationMethod);
		for(int y = 0; y < Y; y++) {
			for(int x = 0; x < X; x++) {
				c.plane[0].set(x,y,plane[0].get(x,y));
				c.plane[1].set(x,y,plane[1].get(x,y));
				c.plane[2].set(x,y,plane[2].get(x,y));
			}
		}
		return c;
	}

	
	
	/*
		 interpolation routines
		 
		 three different methods are available: <P>
		 replication, linear interpolation and cubic interpolation
	*/

	public int getInterpolationMethod() {
		return interpolationMethod;
	}

	public void setInterpolationMethod(int m) {
		if(m == NEIGHBOR || m == LINEAR || m == CUBIC) {
			interpolationMethod = m;
			((InterpolatedRealGrayImage)plane[0]).setInterpolationMethod(m);
			((InterpolatedRealGrayImage)plane[1]).setInterpolationMethod(m);
			((InterpolatedRealGrayImage)plane[2]).setInterpolationMethod(m);
		}
	}
	
	public float[] interp(float x, float y) {
		float[] color = new float[3];
		color[0] = ((InterpolatedRealGrayImage)plane[0]).interp(x,y);
		color[1] = ((InterpolatedRealGrayImage)plane[1]).interp(x,y);
		color[2] = ((InterpolatedRealGrayImage)plane[2]).interp(x,y);
		return color;
	}
		
	public void accum(float x, float y, float[] value) {
		((InterpolatedRealGrayImage)plane[0]).accum(x,y,value[0]);
		((InterpolatedRealGrayImage)plane[1]).accum(x,y,value[1]);
		((InterpolatedRealGrayImage)plane[2]).accum(x,y,value[2]);
	}
		
	public void splat(float x, float y, float[] value) {
		((InterpolatedRealGrayImage)plane[0]).splat(x,y,value[0]);
		((InterpolatedRealGrayImage)plane[1]).splat(x,y,value[1]);
		((InterpolatedRealGrayImage)plane[2]).splat(x,y,value[2]);
	}
	
}
